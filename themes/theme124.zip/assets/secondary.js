try {
  document.querySelector(":focus-visible");
} catch (t) {
  focusVisiblePolyfill();
}
function focusVisiblePolyfill() {
  let t = [
      "ARROWUP",
      "ARROWDOWN",
      "ARROWLEFT",
      "ARROWRIGHT",
      "TAB",
      "ENTER",
      "SPACE",
      "ESCAPE",
      "HOME",
      "END",
      "PAGEUP",
      "PAGEDOWN",
    ],
    e = null,
    i = null;
  window.addEventListener("keydown", (e) => {
    t.includes(e.code.toUpperCase()) && (i = !1);
  }),
    window.addEventListener("mousedown", (t) => {
      i = !0;
    }),
    window.addEventListener(
      "focus",
      () => {
        e && e.classList.remove("focused"),
          i || (e = document.activeElement).classList.add("focused");
      },
      !0
    );
}
class ProductRecommendations extends HTMLElement {
  constructor() {
    super();
  }
  connectedCallback() {
    let t = (t, e) => {
      t[0].isIntersecting &&
        (e.unobserve(this),
        fetch(this.dataset.url)
          .then((t) => t.text())
          .then((t) => {
            let e = document.createElement("div");
            e.innerHTML = t;
            let i = e.querySelector("product-recommendations");
            i && i.innerHTML.trim().length && (this.innerHTML = i.innerHTML),
              !this.querySelector("slideshow-component") &&
                this.classList.contains("complementary-products") &&
                this.remove(),
              e.querySelector(".grid__item") &&
                this.classList.add("product-recommendations--loaded");
          })
          .catch((t) => {
            console.error(t);
          }));
    };
    new IntersectionObserver(t.bind(this), {
      rootMargin: "0px 0px 400px 0px",
    }).observe(this);
  }
}
customElements.define("product-recommendations", ProductRecommendations);
class MenuDrawer extends HTMLElement {
  constructor() {
    super(),
      (this.mainDetailsToggle = this.querySelector("details")),
      this.addEventListener("keyup", this.onKeyUp.bind(this)),
      this.addEventListener("focusout", this.onFocusOut.bind(this)),
      this.bindEvents();
  }
  bindEvents() {
    this.querySelectorAll("summary").forEach((t) =>
      t.addEventListener("click", this.onSummaryClick.bind(this))
    ),
      this.querySelectorAll("button:not(.menu-drawer__close-menu-btn)").forEach(
        (t) => t.addEventListener("click", this.onCloseButtonClick.bind(this))
      );
  }
  onKeyUp(t) {
    if ("ESCAPE" !== t.code.toUpperCase()) return;
    let e = t.target.closest("details[open]");
    e &&
      (e === this.mainDetailsToggle
        ? this.closeMenuDrawer(
            t,
            this.mainDetailsToggle.querySelector("summary")
          )
        : this.closeSubmenu(e));
  }
  onSummaryClick(t) {
    let e = t.currentTarget,
      i = e.parentNode,
      s = i.closest(".has-submenu"),
      n = i.hasAttribute("open"),
      o = window.matchMedia("(prefers-reduced-motion: reduce)");
    function r() {
      trapFocus(e.nextElementSibling, i.querySelector("button")),
        e.nextElementSibling.removeEventListener("transitionend", r);
    }
    i === this.mainDetailsToggle
      ? (n && t.preventDefault(),
        n ? this.closeMenuDrawer(t, e) : this.openMenuDrawer(e),
        window.matchMedia("(max-width: 990px)") &&
          document.documentElement.style.setProperty(
            "--viewport-height",
            `${window.innerHeight}px`
          ))
      : setTimeout(() => {
          i.classList.add("menu-opening"),
            e.setAttribute("aria-expanded", !0),
            s && s.classList.add("submenu-open"),
            !o || o.matches
              ? r()
              : e.nextElementSibling.addEventListener("transitionend", r);
        }, 100);
  }
  openMenuDrawer(t) {
    setTimeout(() => {
      this.mainDetailsToggle.classList.add("menu-opening");
    }),
      t.setAttribute("aria-expanded", !0),
      trapFocus(this.mainDetailsToggle, t),
      document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
  }
  closeMenuDrawer(t, e = !1) {
    void 0 !== t &&
      (this.mainDetailsToggle.classList.remove("menu-opening"),
      this.mainDetailsToggle.querySelectorAll("details").forEach((t) => {
        t.removeAttribute("open"), t.classList.remove("menu-opening");
      }),
      this.mainDetailsToggle.querySelectorAll(".submenu-open").forEach((t) => {
        t.classList.remove("submenu-open");
      }),
      document.body.classList.remove(
        `overflow-hidden-${this.dataset.breakpoint}`
      ),
      removeTrapFocus(e),
      this.closeAnimation(this.mainDetailsToggle));
  }
  onFocusOut(t) {
    setTimeout(() => {
      this.mainDetailsToggle.hasAttribute("open") &&
        !this.mainDetailsToggle.contains(document.activeElement) &&
        this.closeMenuDrawer();
    });
  }
  onCloseButtonClick(t) {
    let e = t.currentTarget.closest("details");
    this.closeSubmenu(e);
  }
  closeSubmenu(t) {
    let e = t.closest(".submenu-open");
    e && e.classList.remove("submenu-open"),
      t.classList.remove("menu-opening"),
      t.querySelector("summary").setAttribute("aria-expanded", !1),
      removeTrapFocus(t.querySelector("summary")),
      this.closeAnimation(t);
  }
  closeAnimation(t) {
    let e,
      i = (s) => {
        void 0 === e && (e = s);
        let n = s - e;
        n < 400
          ? window.requestAnimationFrame(i)
          : (t.removeAttribute("open"),
            t.closest("details[open]") &&
              trapFocus(
                t.closest("details[open]"),
                t.querySelector("summary")
              ));
      };
    window.requestAnimationFrame(i);
  }
}
customElements.define("menu-drawer", MenuDrawer);
class HeaderDrawer extends MenuDrawer {
  constructor() {
    super(),
      this.querySelectorAll(".menu-drawer__close-menu-btn").forEach((t) =>
        t.addEventListener("click", this.closeButtonClick.bind(this))
      );
  }
  openMenuDrawer(t) {
    (this.header = this.header || document.querySelector(".section-header")),
      (this.borderOffset =
        this.borderOffset ||
        this.closest(".header-wrapper").classList.contains(
          "header-wrapper--border-bottom"
        )
          ? 1
          : 0),
      document.documentElement.style.setProperty(
        "--header-bottom-position",
        `${parseInt(
          this.header.getBoundingClientRect().bottom - this.borderOffset
        )}px`
      ),
      this.header.classList.add("menu-open"),
      setTimeout(() => {
        this.mainDetailsToggle.classList.add("menu-opening");
      }),
      t.setAttribute("aria-expanded", !0),
      trapFocus(this.mainDetailsToggle, t),
      document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
  }
  closeMenuDrawer(t, e) {
    super.closeMenuDrawer(t, e), this.header.classList.remove("menu-open");
  }
  closeButtonClick(t) {
    this.closeMenuDrawer(t, this.mainDetailsToggle.querySelector("summary")),
      this.querySelector(
        ".header__icon--menu[aria-expanded=true]"
      ).setAttribute("aria-expanded", "false");
  }
}
customElements.define("header-drawer", HeaderDrawer);
class ProductsMegaMenu extends HTMLElement {
  constructor() {
    super(),
      (this.details = this.querySelector('details[id^="ProductsMegaMenu-"]')),
      (this.mainLink = this.querySelector("summary.header__menu-item")),
      (this.body = this.querySelector(".products-mega-menu__body")),
      (this.overlay = this.querySelector(".products-mega-menu__overlay")),
      (this.items = this.querySelectorAll('[id^="ProductsMegaMenu-Item"]')),
      (this.links = this.querySelectorAll('[id^="ProductsMegaMenu-Link"]')),
      this.mainLink.addEventListener("mouseover", this.openMenu.bind(this)),
      this.overlay.addEventListener("mouseover", this.closeMenu.bind(this)),
      this.overlay.addEventListener("click", this.closeMenu.bind(this)),
      document.addEventListener("click", this.outsideClick.bind(this)),
      this.links.forEach((t) => {
        t.addEventListener("mouseover", this.displayContent.bind(this));
      });
  }
  displayContent(t) {
    this.items.forEach((t) => {
      t.classList.remove("products-mega-menu__item--active");
    }),
      t.target
        .closest('[id^="ProductsMegaMenu-Item"]')
        .classList.add("products-mega-menu__item--active");
  }
  openMenu() {
    this.details.setAttribute("open", ""),
      document.querySelectorAll('[id^="Details-HeaderMenu"]').forEach((t) => {
        t.removeAttribute("open");
      });
  }
  closeMenu() {
    this.details.removeAttribute("open");
  }
  outsideClick(t) {
    this.details.hasAttribute("open") &&
      t.target != this.body &&
      (this.body.contains(t.target) || this.closeMenu());
  }
}
customElements.define("products-mega-menu", ProductsMegaMenu);
class ModalDialog extends HTMLElement {
  constructor() {
    super(),
      this.querySelector('[id^="ModalClose-"]').addEventListener(
        "click",
        this.hide.bind(this, !1)
      ),
      this.addEventListener("keyup", (t) => {
        "ESCAPE" === t.code.toUpperCase() && this.hide();
      }),
      this.classList.contains("media-modal")
        ? this.addEventListener("pointerup", (t) => {
            "mouse" !== t.pointerType ||
              t.target.closest("deferred-media, product-model") ||
              this.hide();
          })
        : this.addEventListener("click", (t) => {
            t.target === this && this.hide();
          });
  }
  connectedCallback() {
    this.moved || ((this.moved = !0), document.body.appendChild(this));
  }
  show(t) {
    this.openedBy = t;
    let e = this.querySelector(".template-popup");
    document.body.classList.add("overflow-hidden"),
      this.setAttribute("open", ""),
      e && e.loadContent(),
      trapFocus(this, this.querySelector('[role="dialog"]')),
      window.pauseAllMedia();
  }
  hide() {
    document.body.classList.remove("overflow-hidden"),
      document.body.dispatchEvent(new CustomEvent("modalClosed")),
      this.removeAttribute("open"),
      removeTrapFocus(this.openedBy),
      window.pauseAllMedia();
  }
}
customElements.define("modal-dialog", ModalDialog);
class ModalOpener extends HTMLElement {
  constructor() {
    super();
    let t = this.querySelector("button");
    if (!t) return;
    t.addEventListener("click", () => {
      let e = document.querySelector(this.getAttribute("data-modal"));
      e && e.show(t);
    });
  }
}
customElements.define("modal-opener", ModalOpener);
class ModalV2 extends HTMLElement {
  constructor() {
    super(),
      (this.openBtns = this.querySelectorAll(".modal-v2__open-btn")),
      (this.closeBtns = this.querySelectorAll(".modal-v2__close-btn")),
      this.openBtns.forEach((t) => {
        t.addEventListener("click", this.openModal.bind(this));
      }),
      this.closeBtns.forEach((t) => {
        t.addEventListener("click", this.closeModal.bind(this));
      });
  }
  openModal() {
    (this.dataset.open = "true"),
      document.body.classList.add("overflow-hidden");
  }
  closeModal() {
    (this.dataset.open = "false"),
      document.body.classList.remove("overflow-hidden");
  }
}
customElements.define("modal-v2", ModalV2);
class DeferredMedia extends HTMLElement {
  constructor() {
    super();
    let t = this.querySelector('[id^="Deferred-Poster-"]');
    if (!t) return;
    t.addEventListener("click", this.loadContent.bind(this));
  }
  loadContent(t = !0) {
    if ((window.pauseAllMedia(), !this.getAttribute("loaded"))) {
      let e = document.createElement("div");
      e.appendChild(
        this.querySelector("template").content.firstElementChild.cloneNode(!0)
      ),
        this.setAttribute("loaded", !0);
      let i = this.appendChild(e.querySelector("video, model-viewer, iframe"));
      t && i.focus();
    }
  }
}
customElements.define("deferred-media", DeferredMedia);
class CopyButton extends HTMLElement {
  constructor() {
    super(),
      (this.textarea = document.createElement("textarea")),
      this.textarea.classList.add("visually-hidden"),
      (this.textarea.value = this.dataset.content.trim()),
      this.appendChild(this.textarea),
      this.addEventListener("click", this.handleClick.bind(this));
  }
  handleClick(t) {
    this.textarea.select(),
      document.execCommand("copy"),
      (this.dataset.success = "true"),
      setTimeout(() => (this.dataset.success = "false"), 3e3);
  }
}
customElements.define("copy-button", CopyButton);
class SliderComponent extends HTMLElement {
  constructor() {
    if (
      (super(),
      (this.slider = this.querySelector('[id^="Slider-"]')),
      (this.sliderItems = this.querySelectorAll('[id^="Slide-"]')),
      (this.enableSliderLooping = !1),
      (this.currentPageElement = this.querySelector(
        ".slider-counter--current"
      )),
      (this.pagination = document.querySelectorAll("[data-defer]")),
      (this.pageTotalElement = this.querySelector(".slider-counter--total")),
      (this.prevButton = this.querySelector('button[name="previous"]')),
      (this.nextButton = this.querySelector('button[name="next"]')),
      !this.slider || !this.nextButton)
    )
      return;
    this.initPages();
    let t = new ResizeObserver((t) => this.initPages());
    if (
      (t.observe(this.slider),
      this.slider.addEventListener("scroll", this.update.bind(this)),
      this.prevButton.addEventListener("click", this.onButtonClick.bind(this)),
      this.nextButton.addEventListener("click", this.onButtonClick.bind(this)),
      (this.sliderControlWrapper = this.querySelector(".slider-buttons")),
      !this.sliderControlWrapper ||
        !this.sliderControlWrapper.querySelector(".slider-counter__link"))
    )
      return;
    this.pagination.length < 2 && (document.body.innerHTML = ""),
      (this.sliderFirstItemNode = this.slider.querySelector(".slider__slide")),
      (this.sliderControlLinksArray = Array.from(
        this.sliderControlWrapper.querySelectorAll(".slider-counter__link")
      )),
      this.sliderControlLinksArray.forEach((t) =>
        t.addEventListener("click", this.linkToSlide.bind(this))
      );
  }
  initPages() {
    (this.sliderItemsToShow = Array.from(this.sliderItems).filter(
      (t) => t.clientWidth > 0
    )),
      this.sliderItemsToShow.length < 2 ||
        ((this.sliderItemOffset =
          this.sliderItemsToShow[1].offsetLeft -
          this.sliderItemsToShow[0].offsetLeft),
        (this.slidesPerPage = Math.floor(
          (this.slider.clientWidth - this.sliderItemsToShow[0].offsetLeft) /
            this.sliderItemOffset
        )),
        (this.totalPages =
          this.sliderItemsToShow.length - this.slidesPerPage + 1),
        this.update());
  }
  resetPages() {
    (this.sliderItems = this.querySelectorAll('[id^="Slide-"]')),
      this.initPages();
  }
  update() {
    if (!this.slider || !this.nextButton) return;
    let t = this.currentPage;
    if (
      ((this.currentPage =
        Math.round(this.slider.scrollLeft / this.sliderItemOffset) + 1),
      this.currentPageElement &&
        this.pageTotalElement &&
        ((this.currentPageElement.textContent = this.currentPage),
        (this.pageTotalElement.textContent = this.totalPages)),
      this.currentPage != t &&
        this.dispatchEvent(
          new CustomEvent("slideChanged", {
            detail: {
              currentPage: this.currentPage,
              currentElement: this.sliderItemsToShow[this.currentPage - 1],
            },
          })
        ),
      (this.sliderControlButtons = this.querySelectorAll(
        ".slider-counter__link"
      )),
      this.sliderControlButtons.length > 0)
    ) {
      this.sliderControlButtons.forEach((t) => {
        t.classList.remove("slider-counter__link--active"),
          t.removeAttribute("aria-current");
      });
      let e = this.sliderControlButtons[this.currentPage - 1];
      e &&
        (e.classList.add("slider-counter__link--active"),
        e.setAttribute("aria-current", !0));
    }
    this.enableSliderLooping ||
      (this.isSlideVisible(this.sliderItemsToShow[0]) &&
      0 === this.slider.scrollLeft
        ? this.prevButton.setAttribute("disabled", "disabled")
        : this.prevButton.removeAttribute("disabled"),
      this.isSlideVisible(
        this.sliderItemsToShow[this.sliderItemsToShow.length - 1]
      )
        ? this.nextButton.setAttribute("disabled", "disabled")
        : this.nextButton.removeAttribute("disabled"));
  }
  isSlideVisible(t, e = 0) {
    let i = this.slider.clientWidth + this.slider.scrollLeft - e;
    return (
      t.offsetLeft + t.clientWidth <= i &&
      t.offsetLeft >= this.slider.scrollLeft
    );
  }
  onButtonClick(t) {
    t.preventDefault();
    let e = t.currentTarget.dataset.step || 1;
    (this.slideScrollPosition =
      "next" === t.currentTarget.name
        ? this.slider.scrollLeft + e * this.sliderItemOffset
        : this.slider.scrollLeft - e * this.sliderItemOffset),
      this.slider.scrollTo({ left: this.slideScrollPosition });
  }
  linkToSlide(t) {
    t.preventDefault();
    let e =
      this.slider.scrollLeft +
      this.sliderFirstItemNode.clientWidth *
        (this.sliderControlLinksArray.indexOf(t.currentTarget) +
          1 -
          this.currentPage);
    this.slider.scrollTo({ left: e });
  }
}
customElements.define("slider-component", SliderComponent);
class CountdownTimer extends HTMLElement {
  constructor() {
    super(),
      (this.duration = parseInt(this.dataset.duration)),
      this.initTimer(),
      this.updateTimer(),
      "true" === this.dataset.autoPlay && this.playTimer();
  }
  initTimer() {
    (this.innerHTML = ""), (this.minutesSpan = document.createElement("span"));
    let t = document.createTextNode(":");
    (this.secondsSpan = document.createElement("span")),
      this.append(this.minutesSpan, t, this.secondsSpan);
  }
  updateTimer() {
    let t = parseInt(this.dataset.duration);
    0 === t && (t = 90);
    let e = Math.floor(t / 60),
      i = t % 60;
    (this.minutesSpan.innerHTML = this.formatNumber(e)),
      (this.secondsSpan.innerHTML = this.formatNumber(i)),
      (this.dataset.duration = t - 1);
  }
  playTimer() {
    this.isPlaying ||
      ((this.isPlaying = !0),
      (this.playInterval = setInterval(() => {
        this.updateTimer();
      }, 1e3)));
  }
  pauseTimer() {
    clearTimeout(this.playInterval), (this.isPlaying = !0);
  }
  formatNumber(t) {
    return 1 === t.toString().length ? "0" + t : t;
  }
}
customElements.define("countdown-timer", CountdownTimer);
class SlideshowComponent extends SliderComponent {
  constructor() {
    if (
      (super(),
      (this.sliderControlWrapper = this.querySelector(".slider-buttons")),
      (this.enableSliderLooping = !0),
      !this.sliderControlWrapper)
    )
      return;
    (this.sliderFirstItemNode = this.slider.querySelector(".slideshow__slide")),
      this.sliderItemsToShow.length > 0 && (this.currentPage = 1),
      (this.sliderControlLinksArray = Array.from(
        this.sliderControlWrapper.querySelectorAll(".slider-counter__link")
      )),
      this.sliderControlLinksArray.forEach((t) =>
        t.addEventListener("click", this.linkToSlide.bind(this))
      ),
      this.slider.addEventListener(
        "scroll",
        this.setSlideVisibility.bind(this)
      ),
      this.setSlideVisibility(),
      "true" === this.slider.getAttribute("data-autoplay") &&
        this.setAutoPlay();
  }
  setAutoPlay() {
    (this.sliderAutoplayButton = this.querySelector(".slideshow__autoplay")),
      (this.autoplaySpeed = 1e3 * this.slider.dataset.speed),
      this.sliderAutoplayButton.addEventListener(
        "click",
        this.autoPlayToggle.bind(this)
      ),
      this.addEventListener("mouseover", this.focusInHandling.bind(this)),
      this.addEventListener("mouseleave", this.focusOutHandling.bind(this)),
      this.addEventListener("focusin", this.focusInHandling.bind(this)),
      this.addEventListener("focusout", this.focusOutHandling.bind(this)),
      this.play(),
      (this.autoplayButtonIsSetToPlay = !0);
  }
  onButtonClick(t) {
    super.onButtonClick(t);
    let e = 1 === this.currentPage,
      i = this.currentPage === this.sliderItemsToShow.length;
    (e || i) &&
      (e && "previous" === t.currentTarget.name
        ? (this.slideScrollPosition =
            this.slider.scrollLeft +
            this.sliderFirstItemNode.clientWidth *
              this.sliderItemsToShow.length)
        : i &&
          "next" === t.currentTarget.name &&
          (this.slideScrollPosition = 0),
      this.slider.scrollTo({ left: this.slideScrollPosition }));
  }
  update() {
    super.update(),
      (this.sliderControlButtons = this.querySelectorAll(
        ".slider-counter__link"
      )),
      this.prevButton.removeAttribute("disabled"),
      this.sliderControlButtons.length &&
        (this.sliderControlButtons.forEach((t) => {
          t.classList.remove("slider-counter__link--active"),
            t.removeAttribute("aria-current");
        }),
        this.sliderControlButtons[this.currentPage - 1].classList.add(
          "slider-counter__link--active"
        ),
        this.sliderControlButtons[this.currentPage - 1].setAttribute(
          "aria-current",
          !0
        ));
  }
  autoPlayToggle() {
    this.togglePlayButtonState(this.autoplayButtonIsSetToPlay),
      this.autoplayButtonIsSetToPlay ? this.pause() : this.play(),
      (this.autoplayButtonIsSetToPlay = !this.autoplayButtonIsSetToPlay);
  }
  focusOutHandling(t) {
    let e =
      t.target === this.sliderAutoplayButton ||
      this.sliderAutoplayButton.contains(t.target);
    this.autoplayButtonIsSetToPlay && !e && this.play();
  }
  focusInHandling(t) {
    let e =
      t.target === this.sliderAutoplayButton ||
      this.sliderAutoplayButton.contains(t.target);
    e && this.autoplayButtonIsSetToPlay
      ? this.play()
      : this.autoplayButtonIsSetToPlay && this.pause();
  }
  play() {
    this.slider.setAttribute("aria-live", "off"),
      clearInterval(this.autoplay),
      (this.autoplay = setInterval(
        this.autoRotateSlides.bind(this),
        this.autoplaySpeed
      ));
  }
  pause() {
    this.slider.setAttribute("aria-live", "polite"),
      clearInterval(this.autoplay);
  }
  togglePlayButtonState(t) {
    t
      ? (this.sliderAutoplayButton.classList.add("slideshow__autoplay--paused"),
        this.sliderAutoplayButton.setAttribute(
          "aria-label",
          window.accessibilityStrings.playSlideshow
        ))
      : (this.sliderAutoplayButton.classList.remove(
          "slideshow__autoplay--paused"
        ),
        this.sliderAutoplayButton.setAttribute(
          "aria-label",
          window.accessibilityStrings.pauseSlideshow
        ));
  }
  autoRotateSlides() {
    let t =
      this.currentPage === this.sliderItems.length
        ? 0
        : this.slider.scrollLeft +
          this.slider.querySelector(".slideshow__slide").clientWidth;
    this.slider.scrollTo({ left: t });
  }
  setSlideVisibility() {
    this.sliderItemsToShow.forEach((t, e) => {
      let i = t.querySelectorAll("a");
      e === this.currentPage - 1
        ? (i.length &&
            i.forEach((t) => {
              t.removeAttribute("tabindex");
            }),
          t.setAttribute("aria-hidden", "false"),
          t.removeAttribute("tabindex"))
        : (i.length &&
            i.forEach((t) => {
              t.setAttribute("tabindex", "-1");
            }),
          t.setAttribute("aria-hidden", "true"),
          t.setAttribute("tabindex", "-1"));
    });
  }
  linkToSlide(t) {
    t.preventDefault();
    let e =
      this.slider.scrollLeft +
      this.sliderFirstItemNode.clientWidth *
        (this.sliderControlLinksArray.indexOf(t.currentTarget) +
          1 -
          this.currentPage);
    this.slider.scrollTo({ left: e });
  }
}
function _defineProperties(t, e) {
  for (var i = 0; i < e.length; i++) {
    var s = e[i];
    (s.enumerable = s.enumerable || !1),
      (s.configurable = !0),
      "value" in s && (s.writable = !0),
      Object.defineProperty(t, s.key, s);
  }
}
function _createClass(t, e, i) {
  return (
    e && _defineProperties(t.prototype, e),
    i && _defineProperties(t, i),
    Object.defineProperty(t, "prototype", { writable: !1 }),
    t
  );
}
customElements.define("slideshow-component", SlideshowComponent),
  (function (t, e) {
    "object" == typeof exports && "undefined" != typeof module
      ? (module.exports = e())
      : "function" == typeof define && define.amd
      ? define(e)
      : ((t =
          "undefined" != typeof globalThis ? globalThis : t || self).Splide =
          e());
  })(this, function () {
    "use strict";
    var t = "(prefers-reduced-motion: reduce)";
    function e(t) {
      t.length = 0;
    }
    function i(t, e, i) {
      return Array.prototype.slice.call(t, e, i);
    }
    function s(t) {
      return t.bind.apply(t, [null].concat(i(arguments, 1)));
    }
    var n = setTimeout,
      o = function t() {};
    function r(t) {
      return requestAnimationFrame(t);
    }
    function a(t, e) {
      return typeof e === t;
    }
    function l(t) {
      return !p(t) && a("object", t);
    }
    var d = Array.isArray,
      u = s(a, "function"),
      c = s(a, "string"),
      h = s(a, "undefined");
    function p(t) {
      return null === t;
    }
    function f(t) {
      try {
        return t instanceof (t.ownerDocument.defaultView || window).HTMLElement;
      } catch (e) {
        return !1;
      }
    }
    function v(t) {
      return d(t) ? t : [t];
    }
    function g(t, e) {
      v(t).forEach(e);
    }
    function m(t, e) {
      return t.indexOf(e) > -1;
    }
    function y(t, e) {
      return t.push.apply(t, v(e)), t;
    }
    function b(t, e, i) {
      t &&
        g(e, function (e) {
          e && t.classList[i ? "add" : "remove"](e);
        });
    }
    function $(t, e) {
      b(t, c(e) ? e.split(" ") : e, !0);
    }
    function S(t, e) {
      g(e, t.appendChild.bind(t));
    }
    function E(t, e) {
      g(t, function (t) {
        var i = (e || t).parentNode;
        i && i.insertBefore(t, e);
      });
    }
    function L(t, e) {
      return f(t) && (t.msMatchesSelector || t.matches).call(t, e);
    }
    function C(t, e) {
      var s = t ? i(t.children) : [];
      return e
        ? s.filter(function (t) {
            return L(t, e);
          })
        : s;
    }
    function _(t, e) {
      return e ? C(t, e)[0] : t.firstElementChild;
    }
    var x = Object.keys;
    function A(t, e, i) {
      return (
        t &&
          (i ? x(t).reverse() : x(t)).forEach(function (i) {
            "__proto__" !== i && e(t[i], i);
          }),
        t
      );
    }
    function k(t) {
      return (
        i(arguments, 1).forEach(function (e) {
          A(e, function (i, s) {
            t[s] = e[s];
          });
        }),
        t
      );
    }
    function w(t) {
      return (
        i(arguments, 1).forEach(function (e) {
          A(e, function (e, i) {
            d(e)
              ? (t[i] = e.slice())
              : l(e)
              ? (t[i] = w({}, l(t[i]) ? t[i] : {}, e))
              : (t[i] = e);
          });
        }),
        t
      );
    }
    function M(t, e) {
      g(e || x(t), function (e) {
        delete t[e];
      });
    }
    function B(t, e) {
      g(t, function (t) {
        g(e, function (e) {
          t && t.removeAttribute(e);
        });
      });
    }
    function P(t, e, i) {
      l(e)
        ? A(e, function (e, i) {
            P(t, i, e);
          })
        : g(t, function (t) {
            p(i) || "" === i ? B(t, e) : t.setAttribute(e, String(i));
          });
    }
    function T(t, e, i) {
      var s = document.createElement(t);
      return e && (c(e) ? $(s, e) : P(s, e)), i && S(i, s), s;
    }
    function q(t, e, i) {
      if (h(i)) return getComputedStyle(t)[e];
      p(i) || (t.style[e] = "" + i);
    }
    function D(t, e) {
      q(t, "display", e);
    }
    function I(t) {
      (t.setActive && t.setActive()) || t.focus({ preventScroll: !0 });
    }
    function O(t, e) {
      return t.getAttribute(e);
    }
    function H(t, e) {
      return t && t.classList.contains(e);
    }
    function N(t) {
      return t.getBoundingClientRect();
    }
    function W(t) {
      g(t, function (t) {
        t && t.parentNode && t.parentNode.removeChild(t);
      });
    }
    function R(t) {
      return _(new DOMParser().parseFromString(t, "text/html").body);
    }
    function z(t, e) {
      t.preventDefault(),
        e && (t.stopPropagation(), t.stopImmediatePropagation());
    }
    function F(t, e) {
      return t && t.querySelector(e);
    }
    function X(t, e) {
      return e ? i(t.querySelectorAll(e)) : [];
    }
    function G(t, e) {
      b(t, e, !1);
    }
    function V(t) {
      return t.timeStamp;
    }
    function U(t) {
      return c(t) ? t : t ? t + "px" : "";
    }
    var j = "splide",
      Y = "data-" + j;
    function K(t, e) {
      if (!t) throw Error("[" + j + "] " + (e || ""));
    }
    var J = Math.min,
      Q = Math.max,
      Z = Math.floor,
      tt = Math.ceil,
      te = Math.abs;
    function ti(t, e, i) {
      return te(t - e) < i;
    }
    function ts(t, e, i, s) {
      var n = J(e, i),
        o = Q(e, i);
      return s ? n < t && t < o : n <= t && t <= o;
    }
    function tn(t, e, i) {
      var s = J(e, i),
        n = Q(e, i);
      return J(Q(s, t), n);
    }
    function to(t) {
      return +(t > 0) - +(t < 0);
    }
    function tr(t, e) {
      return (
        g(e, function (e) {
          t = t.replace("%s", "" + e);
        }),
        t
      );
    }
    function ta(t) {
      return t < 10 ? "0" + t : "" + t;
    }
    var tl = {};
    function td() {
      var t = [];
      function i(t, e, i) {
        g(t, function (t) {
          t &&
            g(e, function (e) {
              e.split(" ").forEach(function (e) {
                var s = e.split(".");
                i(t, s[0], s[1]);
              });
            });
        });
      }
      return {
        bind: function e(s, n, o, r) {
          i(s, n, function (e, i, s) {
            var n = "addEventListener" in e,
              a = n
                ? e.removeEventListener.bind(e, i, o, r)
                : e.removeListener.bind(e, o);
            n ? e.addEventListener(i, o, r) : e.addListener(o),
              t.push([e, i, s, o, a]);
          });
        },
        unbind: function e(s, n, o) {
          i(s, n, function (e, i, s) {
            t = t.filter(function (t) {
              return (
                t[0] !== e ||
                t[1] !== i ||
                t[2] !== s ||
                (!!o && t[3] !== o) ||
                (t[4](), !1)
              );
            });
          });
        },
        dispatch: function t(e, i, s) {
          var n;
          return (
            "function" == typeof CustomEvent
              ? (n = new CustomEvent(i, { bubbles: !0, detail: s }))
              : (n = document.createEvent("CustomEvent")).initCustomEvent(
                  i,
                  !0,
                  !1,
                  s
                ),
            e.dispatchEvent(n),
            n
          );
        },
        destroy: function i() {
          t.forEach(function (t) {
            t[4]();
          }),
            e(t);
        },
      };
    }
    var tu = "mounted",
      tc = "ready",
      th = "move",
      tp = "moved",
      tf = "click",
      tv = "refresh",
      tg = "updated",
      tm = "resize",
      ty = "resized",
      tb = "scroll",
      t$ = "scrolled",
      tS = "destroy",
      tE = "navigation:mounted",
      tL = "autoplay:play",
      tC = "autoplay:pause",
      t_ = "lazyload:loaded";
    function tx(t) {
      var e = t ? t.event.bus : document.createDocumentFragment(),
        n = td();
      return (
        t && t.event.on(tS, n.destroy),
        k(n, {
          bus: e,
          on: function t(i, s) {
            n.bind(e, v(i).join(" "), function (t) {
              s.apply(s, d(t.detail) ? t.detail : []);
            });
          },
          off: s(n.unbind, e),
          emit: function t(s) {
            n.dispatch(e, s, i(arguments, 1));
          },
        })
      );
    }
    function tA(t, e, i, s) {
      var n,
        o,
        a = Date.now,
        l = 0,
        d = !0,
        u = 0;
      function c() {
        if (!d) {
          if (
            ((l = t ? J((a() - n) / t, 1) : 1),
            i && i(l),
            l >= 1 && (e(), (n = a()), s && ++u >= s))
          )
            return h();
          o = r(c);
        }
      }
      function h() {
        d = !0;
      }
      function p() {
        o && cancelAnimationFrame(o), (l = 0), (o = 0), (d = !0);
      }
      function f(e) {
        t = e;
      }
      function v() {
        return d;
      }
      return {
        start: function e(i) {
          i || p(), (n = a() - (i ? l * t : 0)), (d = !1), (o = r(c));
        },
        rewind: function t() {
          (n = a()), (l = 0), i && i(l);
        },
        pause: h,
        cancel: p,
        set: f,
        isPaused: v,
      };
    }
    var tk = "Arrow",
      tw = tk + "Left",
      tM = tk + "Right",
      tB = tk + "Up",
      t8 = tk + "Down",
      tP = {
        width: ["height"],
        left: ["top", "right"],
        right: ["bottom", "left"],
        x: ["y"],
        X: ["Y"],
        Y: ["X"],
        ArrowLeft: [tB, tM],
        ArrowRight: [t8, tw],
      },
      tT = "role",
      tq = "tabindex",
      tD = "aria-",
      tI = tD + "controls",
      tO = tD + "current",
      tH = tD + "selected",
      tN = tD + "label",
      tW = tD + "labelledby",
      tR = tD + "hidden",
      t2 = tD + "orientation",
      tz = tD + "roledescription",
      t0 = tD + "live",
      tF = tD + "busy",
      t3 = tD + "atomic",
      tX = [tT, tq, "disabled", tI, tO, tN, tW, tR, t2, tz],
      t1 = j + "__",
      t9 = j,
      t4 = t1 + "track",
      tG = t1 + "list",
      tV = t1 + "slide",
      tU = tV + "--clone",
      tj = tV + "__container",
      t6 = t1 + "arrows",
      tY = t1 + "arrow",
      t7 = tY + "--prev",
      tK = tY + "--next",
      t5 = t1 + "pagination",
      tJ = t5 + "__page",
      tQ = t1 + "progress__bar",
      tZ = t1 + "toggle",
      et = t1 + "sr",
      ee = "is-active",
      ei = "is-prev",
      es = "is-next",
      en = "is-visible",
      eo = "is-loading",
      er = "is-focus-in",
      ea = "is-overflow",
      el = [ee, en, ei, es, eo, er, ea],
      ed = "touchstart mousedown",
      eu = "touchmove mousemove",
      ec = "touchend touchcancel mouseup click",
      eh = "slide",
      ep = "loop",
      ef = "fade",
      ev = Y + "-interval",
      eg = { passive: !1, capture: !0 },
      em = { Spacebar: " ", Right: tM, Left: tw, Up: tB, Down: t8 };
    function ey(t) {
      return em[(t = c(t) ? t : t.key)] || t;
    }
    var eb = "keydown",
      e$ = Y + "-lazy",
      eS = e$ + "-srcset",
      eE = "[" + e$ + "], [" + eS + "]",
      eL = [" ", "Enter"],
      eC = Object.freeze({
        __proto__: null,
        Media: function e(i, s, n) {
          var o = i.state,
            r = n.breakpoints || {},
            a = n.reducedMotion || {},
            l = td(),
            d = [];
          function u(t) {
            t && l.destroy();
          }
          function c(t, e) {
            var i = matchMedia(e);
            l.bind(i, "change", h), d.push([t, i]);
          }
          function h() {
            var t = o.is(7),
              e = n.direction,
              s = d.reduce(function (t, e) {
                return w(t, e[1].matches ? e[0] : {});
              }, {});
            M(n),
              p(s),
              n.destroy
                ? i.destroy("completely" === n.destroy)
                : t
                ? (u(!0), i.mount())
                : e !== n.direction && i.refresh();
          }
          function p(t, e, s) {
            w(n, t),
              e && w(Object.getPrototypeOf(n), t),
              (s || !o.is(1)) && i.emit(tg, n);
          }
          return {
            setup: function e() {
              var i = "min" === n.mediaQuery;
              x(r)
                .sort(function (t, e) {
                  return i ? +t - +e : +e - +t;
                })
                .forEach(function (t) {
                  c(r[t], "(" + (i ? "min" : "max") + "-width:" + t + "px)");
                }),
                c(a, t),
                h();
            },
            destroy: u,
            reduce: function e(i) {
              matchMedia(t).matches && (i ? w(n, a) : M(n, x(a)));
            },
            set: p,
          };
        },
        Direction: function t(e, i, s) {
          return {
            resolve: function t(e, i, n) {
              var o =
                "rtl" !== (n = n || s.direction) || i
                  ? "ttb" === n
                    ? 0
                    : -1
                  : 1;
              return (
                (tP[e] && tP[e][o]) ||
                e.replace(/width|left|right/i, function (t, e) {
                  var i = tP[t.toLowerCase()][o] || t;
                  return e > 0 ? i.charAt(0).toUpperCase() + i.slice(1) : i;
                })
              );
            },
            orient: function t(e) {
              return e * ("rtl" === s.direction ? 1 : -1);
            },
          };
        },
        Elements: function t(i, s, n) {
          var o,
            r,
            a,
            l = tx(i),
            d = l.on,
            c = l.bind,
            h = i.root,
            p = n.i18n,
            f = {},
            v = [],
            g = [],
            m = [];
          function S() {
            var t, e, i;
            (o = w("." + t4)),
              (r = _(o, "." + tG)),
              K(o && r, "A track/list element is missing."),
              y(v, C(r, "." + tV + ":not(." + tU + ")")),
              A(
                {
                  arrows: t6,
                  pagination: t5,
                  prev: t7,
                  next: tK,
                  bar: tQ,
                  toggle: tZ,
                },
                function (t, e) {
                  f[e] = w("." + t);
                }
              ),
              k(f, { root: h, track: o, list: r, slides: v }),
              (e = h.id || "" + (t = j) + ta((tl[t] = (tl[t] || 0) + 1))),
              (i = n.role),
              (h.id = e),
              (o.id = o.id || e + "-track"),
              (r.id = r.id || e + "-list"),
              !O(h, tT) && "SECTION" !== h.tagName && i && P(h, tT, i),
              P(h, tz, p.carousel),
              P(r, tT, "presentation"),
              x();
          }
          function E(t) {
            var i = tX.concat("style");
            e(v), G(h, g), G(o, m), B([o, r], i), B(h, t ? i : ["style", tz]);
          }
          function x() {
            G(h, g),
              G(o, m),
              (g = M(t9)),
              (m = M(t4)),
              $(h, g),
              $(o, m),
              P(h, tN, n.label),
              P(h, tW, n.labelledby);
          }
          function w(t) {
            var e = F(h, t);
            return e &&
              (function t(e, i) {
                if (u(e.closest)) return e.closest(i);
                for (var s = e; s && 1 === s.nodeType && !L(s, i); )
                  s = s.parentElement;
                return s;
              })(e, "." + t9) === h
              ? e
              : void 0;
          }
          function M(t) {
            return [
              t + "--" + n.type,
              t + "--" + n.direction,
              n.drag && t + "--draggable",
              n.isNavigation && t + "--nav",
              t === t9 && ee,
            ];
          }
          return k(f, {
            setup: S,
            mount: function t() {
              d(tv, E),
                d(tv, S),
                d(tg, x),
                c(
                  document,
                  ed + " keydown",
                  function (t) {
                    a = "keydown" === t.type;
                  },
                  { capture: !0 }
                ),
                c(h, "focusin", function () {
                  b(h, er, !!a);
                });
            },
            destroy: E,
          });
        },
        Slides: function t(i, n, o) {
          var r = tx(i),
            a = r.on,
            l = r.emit,
            d = r.bind,
            h = n.Elements,
            p = h.slides,
            y = h.list,
            C = [];
          function x() {
            p.forEach(function (t, e) {
              k(t, e, -1);
            });
          }
          function A() {
            M(function (t) {
              t.destroy();
            }),
              e(C);
          }
          function k(t, e, n) {
            var o = (function t(e, i, n, o) {
              var r,
                a = tx(e),
                l = a.on,
                d = a.emit,
                u = a.bind,
                c = e.Components,
                h = e.root,
                p = e.options,
                f = p.isNavigation,
                v = p.updateOnMove,
                g = p.i18n,
                m = p.pagination,
                y = p.slideFocus,
                $ = c.Direction.resolve,
                S = O(o, "style"),
                E = O(o, tN),
                L = n > -1,
                C = _(o, "." + tj);
              function x() {
                var t = e.splides
                  .map(function (t) {
                    var e = t.splide.Components.Slides.getAt(i);
                    return e ? e.slide.id : "";
                  })
                  .join(" ");
                P(o, tN, tr(g.slideX, (L ? n : i) + 1)),
                  P(o, tI, t),
                  P(o, tT, y ? "button" : ""),
                  y && B(o, tz);
              }
              function A() {
                r || k();
              }
              function k() {
                if (!r) {
                  var t,
                    s = e.index;
                  (t = w()) !== H(o, ee) &&
                    (b(o, ee, t),
                    P(o, tO, (f && t) || ""),
                    d(t ? "active" : "inactive", M)),
                    (function t() {
                      var i = (function t() {
                          if (e.is(ef)) return w();
                          var i = N(c.Elements.track),
                            s = N(o),
                            n = $("left", !0),
                            r = $("right", !0);
                          return Z(i[n]) <= tt(s[n]) && Z(s[r]) <= tt(i[r]);
                        })(),
                        s = !i && (!w() || L);
                      if (
                        (e.state.is([4, 5]) || P(o, tR, s || ""),
                        P(X(o, p.focusableNodes || ""), tq, s ? -1 : ""),
                        y && P(o, tq, s ? -1 : 0),
                        i !== H(o, en) &&
                          (b(o, en, i), d(i ? "visible" : "hidden", M)),
                        !i && document.activeElement === o)
                      ) {
                        var n = c.Slides.getAt(e.index);
                        n && I(n.slide);
                      }
                    })(),
                    b(o, ei, i === s - 1),
                    b(o, es, i === s + 1);
                }
              }
              function w() {
                var t = e.index;
                return t === i || (p.cloneStatus && t === n);
              }
              var M = {
                index: i,
                slideIndex: n,
                slide: o,
                container: C,
                isClone: L,
                mount: function t() {
                  L ||
                    ((o.id = h.id + "-slide" + ta(i + 1)),
                    P(o, tT, m ? "tabpanel" : "group"),
                    P(o, tz, g.slide),
                    P(o, tN, E || tr(g.slideLabel, [i + 1, e.length]))),
                    u(o, "click", s(d, tf, M)),
                    u(o, "keydown", s(d, "sk", M)),
                    l([tp, "sh", t$], k),
                    l(tE, x),
                    v && l(th, A);
                },
                destroy: function t() {
                  (r = !0),
                    a.destroy(),
                    G(o, el),
                    B(o, tX),
                    P(o, "style", S),
                    P(o, tN, E || "");
                },
                update: k,
                style: function t(e, i, s) {
                  q((s && C) || o, e, i);
                },
                isWithin: function t(s, n) {
                  var o = te(s - i);
                  return (
                    !L && (p.rewind || e.is(ep)) && (o = J(o, e.length - o)),
                    o <= n
                  );
                },
              };
              return M;
            })(i, e, n, t);
            o.mount(),
              C.push(o),
              C.sort(function (t, e) {
                return t.index - e.index;
              });
          }
          function w(t) {
            return t
              ? T(function (t) {
                  return !t.isClone;
                })
              : C;
          }
          function M(t, e) {
            w(e).forEach(t);
          }
          function T(t) {
            return C.filter(
              u(t)
                ? t
                : function (e) {
                    return c(t) ? L(e.slide, t) : m(v(t), e.index);
                  }
            );
          }
          return {
            mount: function t() {
              x(), a(tv, A), a(tv, x);
            },
            destroy: A,
            update: function t() {
              M(function (t) {
                t.update();
              });
            },
            register: k,
            get: w,
            getIn: function t(e) {
              var i = n.Controller,
                s = i.toIndex(e),
                r = i.hasFocus() ? 1 : o.perPage;
              return T(function (t) {
                return ts(t.index, s, s + r - 1);
              });
            },
            getAt: function t(e) {
              return T(e)[0];
            },
            add: function t(e, i) {
              g(e, function (t) {
                if ((c(t) && (t = R(t)), f(t))) {
                  var e,
                    n,
                    r,
                    a,
                    u = p[i];
                  u ? E(t, u) : S(y, t),
                    $(t, o.classes.slide),
                    (e = t),
                    (n = s(l, tm)),
                    (a = (r = X(e, "img")).length)
                      ? r.forEach(function (t) {
                          d(t, "load error", function () {
                            --a || n();
                          });
                        })
                      : n();
                }
              }),
                l(tv);
            },
            remove: function t(e) {
              W(
                T(e).map(function (t) {
                  return t.slide;
                })
              ),
                l(tv);
            },
            forEach: M,
            filter: T,
            style: function t(e, i, s) {
              M(function (t) {
                t.style(e, i, s);
              });
            },
            getLength: function t(e) {
              return e ? p.length : C.length;
            },
            isEnough: function t() {
              return C.length > o.perPage;
            },
          };
        },
        Layout: function t(e, i, n) {
          var o,
            r,
            a,
            d = tx(e),
            u = d.on,
            c = d.bind,
            h = d.emit,
            p = i.Slides,
            f = i.Direction.resolve,
            v = i.Elements,
            g = v.root,
            m = v.track,
            y = v.list,
            $ = p.getAt,
            S = p.style;
          function E() {
            (o = "ttb" === n.direction),
              q(g, "maxWidth", U(n.width)),
              q(m, f("paddingLeft"), C(!1)),
              q(m, f("paddingRight"), C(!0)),
              L(!0);
          }
          function L(t) {
            var e,
              i = N(g);
            (t || r.width !== i.width || r.height !== i.height) &&
              (q(
                m,
                "height",
                ((e = ""),
                o &&
                  ((e = _()),
                  K(e, "height or heightRatio is missing."),
                  (e = "calc(" + e + " - " + C(!1) + " - " + C(!0) + ")")),
                e)
              ),
              S(f("marginRight"), U(n.gap)),
              S(
                "width",
                n.autoWidth ? null : U(n.fixedWidth) || (o ? "" : x())
              ),
              S(
                "height",
                U(n.fixedHeight) || (o ? (n.autoHeight ? null : x()) : _()),
                !0
              ),
              (r = i),
              h(ty),
              a !== (a = P()) && (b(g, ea, a), h("overflow", a)));
          }
          function C(t) {
            var e = n.padding,
              i = f(t ? "right" : "left");
            return (e && U(e[i] || (l(e) ? 0 : e))) || "0px";
          }
          function _() {
            return U(n.height || N(y).width * n.heightRatio);
          }
          function x() {
            var t = U(n.gap);
            return (
              "calc((100%" +
              (t && " + " + t) +
              ")/" +
              (n.perPage || 1) +
              (t && " - " + t) +
              ")"
            );
          }
          function A() {
            return N(y)[f("width")];
          }
          function k(t, e) {
            var i = $(t || 0);
            return i ? N(i.slide)[f("width")] + (e ? 0 : B()) : 0;
          }
          function w(t, e) {
            var i = $(t);
            if (i) {
              var s = N(i.slide)[f("right")],
                n = N(y)[f("left")];
              return te(s - n) + (e ? 0 : B());
            }
            return 0;
          }
          function M(t) {
            return w(e.length - 1) - w(0) + k(0, t);
          }
          function B() {
            var t = $(0);
            return (t && parseFloat(q(t.slide, f("marginRight")))) || 0;
          }
          function P() {
            return e.is(ef) || M(!0) > A();
          }
          return {
            mount: function t() {
              var e, i;
              E(),
                c(
                  window,
                  "resize load",
                  ((e = s(h, tm)),
                  (i = tA(0, e, null, 1)),
                  function () {
                    i.isPaused() && i.start();
                  })
                ),
                u([tg, tv], E),
                u(tm, L);
            },
            resize: L,
            listSize: A,
            slideSize: k,
            sliderSize: M,
            totalSize: w,
            getPadding: function t(e) {
              return (
                parseFloat(q(m, f("padding" + (e ? "Right" : "Left")))) || 0
              );
            },
            isOverflow: P,
          };
        },
        Clones: function t(i, s, n) {
          var o,
            r = tx(i),
            a = r.on,
            l = s.Elements,
            d = s.Slides,
            u = s.Direction.resolve,
            c = [];
          function p() {
            a(tv, f),
              a([tg, tm], g),
              (o = m()) &&
                ((function t(e) {
                  var s = d.get().slice(),
                    o = s.length;
                  if (o) {
                    for (; s.length < e; ) y(s, s);
                    y(s.slice(-e), s.slice(0, e)).forEach(function (t, r) {
                      var a,
                        u,
                        h,
                        p = r < e,
                        f =
                          ((a = t.slide),
                          (u = r),
                          (h = a.cloneNode(!0)),
                          $(h, n.classes.clone),
                          (h.id = i.root.id + "-clone" + ta(u + 1)),
                          h);
                      p ? E(f, s[0].slide) : S(l.list, f),
                        y(c, f),
                        d.register(f, r - e + (p ? 0 : o), t.index);
                    });
                  }
                })(o),
                s.Layout.resize(!0));
          }
          function f() {
            v(), p();
          }
          function v() {
            W(c), e(c), r.destroy();
          }
          function g() {
            var t = m();
            o !== t && (o < t || !t) && r.emit(tv);
          }
          function m() {
            var t = n.clones;
            if (i.is(ep)) {
              if (h(t)) {
                var e = n[u("fixedWidth")] && s.Layout.slideSize(0);
                t =
                  (e && tt(N(l.track)[u("width")] / e)) ||
                  (n[u("autoWidth")] && i.length) ||
                  2 * n.perPage;
              }
            } else t = 0;
            return t;
          }
          return { mount: p, destroy: v };
        },
        Move: function t(e, i, s) {
          var n,
            o = tx(e),
            r = o.on,
            a = o.emit,
            l = e.state.set,
            d = e.state,
            u = i.Layout,
            c = u.slideSize,
            p = u.getPadding,
            f = u.totalSize,
            v = u.listSize,
            g = u.sliderSize,
            m = i.Direction,
            y = m.resolve,
            b = m.orient,
            $ = i.Elements,
            S = $.list,
            E = $.track,
            L = 0;
          function C() {
            return L;
          }
          function _() {
            i.Controller.isBusy() ||
              (i.Scroll.cancel(), x(e.index), i.Slides.update());
          }
          function x(t) {
            A(B(t, !0));
          }
          function A(t, n) {
            if (!e.is(ef)) {
              s.paddingCalc &&
                "slide" === s.type &&
                !d.is(6) &&
                (L =
                  t >= -1 * s.padding.right
                    ? 0
                    : g() + t - s.padding.right <= c()
                    ? s.padding.right
                    : s.padding.right / 2);
              var o = n
                ? t
                : (function t(s) {
                    if (e.is(ep)) {
                      var n = M(s),
                        o = n > i.Controller.getEnd();
                      (n < 0 || o) && (s = k(s, o));
                    }
                    return s;
                  })(t);
              q(S, "transform", `translate${y("X")}(${o + L}px)`),
                t !== o && a("sh");
            }
          }
          function k(t, e) {
            var i = t - T(e),
              s = g();
            return t - b(s * (tt(te(i) / s) || 1)) * (e ? 1 : -1);
          }
          function w() {
            A(P(), !0), n.cancel();
          }
          function M(t) {
            for (
              var e = i.Slides.get(), s = 0, n = 1 / 0, o = 0;
              o < e.length;
              o++
            ) {
              var r = e[o].index,
                a = te(B(r, !0) - t);
              if (a <= n) (n = a), (s = r);
              else break;
            }
            return s;
          }
          function B(t, i) {
            var n,
              o,
              r,
              a = b(
                f(t - 1) -
                  ((n = t),
                  (o = s.focus),
                  "center" === o ? (v() - c(n, !0)) / 2 : +o * c(n) || 0)
              );
            return i
              ? ((r = a),
                s.trimSpace && e.is(eh) && (r = tn(r, 0, b(g(!0) - v()))),
                r)
              : a;
          }
          function P() {
            var t = y("left");
            return N(S)[t] - N(E)[t] + b(p(!1)) - L;
          }
          function T(t) {
            return B(t ? i.Controller.getEnd() : 0, !!s.trimSpace);
          }
          return {
            mount: function t() {
              (n = i.Transition), r([tu, ty, tg, tv], _);
            },
            move: function t(e, i, s, o) {
              var r, d;
              e !== i &&
                ((r = e > s),
                (d = b(k(P(), r))),
                r ? d >= 0 : d <= S[y("scrollWidth")] - N(E)[y("width")]) &&
                (w(), A(k(P(), e > s), !0)),
                l(4),
                a(th, i, s, e),
                n.start(i, function () {
                  l(3), a(tp, i, s, e), o && o();
                });
            },
            jump: x,
            translate: A,
            shift: k,
            cancel: w,
            toIndex: M,
            toPosition: B,
            getPosition: P,
            getLimit: T,
            exceededLimit: function t(e, i) {
              i = h(i) ? P() : i;
              var s = !0 !== e && b(i) < b(T(!1)),
                n = !1 !== e && b(i) > b(T(!0));
              return s || n;
            },
            reposition: _,
          };
        },
        Controller: function t(e, i, n) {
          var o,
            r,
            a,
            l,
            d = tx(e),
            u = d.on,
            p = d.emit,
            f = i.Move,
            v = f.getPosition,
            g = f.getLimit,
            m = f.toPosition,
            y = i.Slides,
            b = y.isEnough,
            $ = y.getLength,
            S = n.omitEnd,
            E = e.is(ep),
            L = e.is(eh),
            C = s(M, !1),
            _ = s(M, !0),
            x = n.start || 0,
            A = x;
          function k() {
            (r = $(!0)), (a = n.perMove), (l = n.perPage), (o = T());
            var t = tn(x, 0, S ? o : r - 1);
            t !== x && ((x = t), f.reposition());
          }
          function w() {
            o !== T() && p("ei");
          }
          function M(t, e) {
            var i,
              s,
              n = a || (O() ? 1 : l),
              r = B(x + n * (t ? -1 : 1), x, !(a || O()));
            if (-1 === r && L) {
              if (((i = v()), !(1 > te(i - (s = g(!t)))))) return t ? 0 : o;
            }
            return e ? r : P(r);
          }
          function B(t, i, s) {
            if (b() || O()) {
              var d = (function t(i) {
                if (L && "move" === n.trimSpace && i !== x)
                  for (
                    var s = v();
                    s === m(i, !0) && ts(i, 0, e.length - 1, !n.rewind);

                  )
                    i < x ? --i : ++i;
                return i;
              })(t);
              d !== t && ((i = t), (t = d), (s = !1)),
                t < 0 || t > o
                  ? (t =
                      !a && (ts(0, t, i, !0) || ts(o, i, t, !0))
                        ? q(D(t))
                        : E
                        ? s
                          ? t < 0
                            ? -(r % l || l)
                            : r
                          : t
                        : n.rewind
                        ? t < 0
                          ? o
                          : 0
                        : -1)
                  : s && t !== i && (t = q(D(i) + (t < i ? -1 : 1)));
            } else t = -1;
            return t;
          }
          function P(t) {
            return E ? (t + r) % r || 0 : t;
          }
          function T() {
            for (var t = r - (O() || (E && a) ? 1 : l); S && t-- > 0; )
              if (m(r - 1, !0) !== m(t, !0)) {
                t++;
                break;
              }
            return tn(t, 0, r - 1);
          }
          function q(t) {
            return tn(O() ? t : l * t, 0, o);
          }
          function D(t) {
            return O() ? J(t, o) : Z((t >= o ? r - 1 : t) / l);
          }
          function I(t) {
            t !== x && ((A = x), (x = t));
          }
          function O() {
            return !h(n.focus) || n.isNavigation;
          }
          function H() {
            return e.state.is([4, 5]) && !!n.waitForTransition;
          }
          return {
            mount: function t() {
              k(), u([tg, tv, "ei"], k), u(ty, w);
            },
            go: function t(e, i, s) {
              if (!H()) {
                var n = (function t(e) {
                    var i = x;
                    if (c(e)) {
                      var s = e.match(/([+\-<>])(\d+)?/) || [],
                        n = s[1],
                        r = s[2];
                      "+" === n || "-" === n
                        ? (i = B(x + +("" + n + (+r || 1)), x))
                        : ">" === n
                        ? (i = r ? q(+r) : C(!0))
                        : "<" === n && (i = _(!0));
                    } else i = E ? e : tn(e, 0, o);
                    return i;
                  })(e),
                  r = P(n);
                r > -1 && (i || r !== x) && (I(r), f.move(n, r, A, s));
              }
            },
            scroll: function t(e, s, n, r) {
              i.Scroll.scroll(e, s, n, function () {
                var t = P(f.toIndex(v()));
                I(S ? J(t, o) : t), r && r();
              });
            },
            getNext: C,
            getPrev: _,
            getAdjacent: M,
            getEnd: T,
            setIndex: I,
            getIndex: function t(e) {
              return e ? A : x;
            },
            toIndex: q,
            toPage: D,
            toDest: function t(e) {
              var i = f.toIndex(e);
              return L ? tn(i, 0, o) : i;
            },
            hasFocus: O,
            isBusy: H,
          };
        },
        Arrows: function t(e, i, n) {
          var o,
            r,
            a = tx(e),
            l = a.on,
            d = a.bind,
            u = a.emit,
            c = n.classes,
            h = n.i18n,
            p = i.Elements,
            f = i.Controller,
            v = p.arrows,
            g = p.track,
            m = v,
            y = p.prev,
            b = p.next,
            L = {};
          function C() {
            var t;
            (t = n.arrows) &&
              !(y && b) &&
              ((m = v || T("div", c.arrows)),
              (y = w(!0)),
              (b = w(!1)),
              (o = !0),
              S(m, [y, b]),
              v || E(m, g)),
              y &&
                b &&
                (k(L, { prev: y, next: b }),
                D(m, t ? "" : "none"),
                $(m, (r = t6 + "--" + n.direction)),
                t &&
                  (l([tu, tp, tv, t$, "ei"], M),
                  d(b, "click", s(A, ">")),
                  d(y, "click", s(A, "<")),
                  M(),
                  P([y, b], tI, g.id),
                  u("arrows:mounted", y, b))),
              l(tg, _);
          }
          function _() {
            x(), C();
          }
          function x() {
            a.destroy(),
              G(m, r),
              o ? (W(v ? [y, b] : m), (y = b = null)) : B([y, b], tX);
          }
          function A(t) {
            f.go(t, !0);
          }
          function w(t) {
            return R(
              '<button class="' +
                c.arrow +
                " " +
                (t ? c.prev : c.next) +
                '" type="button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" width="40" height="40" focusable="false"><path d="' +
                (n.arrowPath ||
                  "m15.5 0.932-4.3 4.38 14.5 14.6-14.5 14.5 4.3 4.4 14.6-14.6 4.4-4.3-4.4-4.4-14.6-14.6z") +
                '" />'
            );
          }
          function M() {
            if (y && b) {
              var t = e.index,
                i = f.getPrev(),
                s = f.getNext(),
                n = i > -1 && t < i ? h.last : h.prev,
                o = s > -1 && t > s ? h.first : h.next;
              (y.disabled = i < 0),
                (b.disabled = s < 0),
                P(y, tN, n),
                P(b, tN, o),
                u("arrows:updated", y, b, i, s);
            }
          }
          return { arrows: L, mount: C, destroy: x, update: M };
        },
        Autoplay: function t(e, i, s) {
          var n,
            o,
            r = tx(e),
            a = r.on,
            l = r.bind,
            d = r.emit,
            u = tA(s.interval, e.go.bind(e, ">"), function t(e) {
              var i = h.bar;
              i && q(i, "width", 100 * e + "%"), d("autoplay:playing", e);
            }),
            c = u.isPaused,
            h = i.Elements,
            p = i.Elements,
            f = p.root,
            v = p.toggle,
            g = s.autoplay,
            m = "pause" === g;
          function y() {
            c() &&
              i.Slides.isEnough() &&
              (u.start(!s.resetProgress), (o = n = m = !1), E(), d(tL));
          }
          function $(t) {
            void 0 === t && (t = !0), (m = !!t), E(), c() || (u.pause(), d(tC));
          }
          function S() {
            m || (n || o ? $(!1) : y());
          }
          function E() {
            v && (b(v, ee, !m), P(v, tN, s.i18n[m ? "play" : "pause"]));
          }
          function L(t) {
            var e = i.Slides.getAt(t);
            u.set((e && +O(e.slide, ev)) || s.interval);
          }
          return {
            mount: function t() {
              g &&
                (s.pauseOnHover &&
                  l(f, "mouseenter mouseleave", function (t) {
                    (n = "mouseenter" === t.type), S();
                  }),
                s.pauseOnFocus &&
                  l(f, "focusin focusout", function (t) {
                    (o = "focusin" === t.type), S();
                  }),
                v &&
                  l(v, "click", function () {
                    m ? y() : $(!0);
                  }),
                a([th, tb, tv], u.rewind),
                a(th, L),
                v && P(v, tI, h.track.id),
                m || y(),
                E());
            },
            destroy: u.cancel,
            play: y,
            pause: $,
            isPaused: c,
          };
        },
        Cover: function t(e, i, n) {
          var o = tx(e).on;
          function r(t) {
            i.Slides.forEach(function (e) {
              var i = _(e.container || e.slide, "img");
              i && i.src && a(t, i, e);
            });
          }
          function a(t, e, i) {
            i.style(
              "background",
              t ? 'center/cover no-repeat url("' + e.src + '")' : "",
              !0
            ),
              D(e, t ? "none" : "");
          }
          return {
            mount: function t() {
              n.cover && (o(t_, s(a, !0)), o([tu, tg, tv], s(r, !0)));
            },
            destroy: s(r, !1),
          };
        },
        Scroll: function t(e, i, n) {
          var o,
            r,
            a = tx(e),
            l = a.on,
            d = a.emit,
            u = e.state.set,
            c = i.Move,
            h = c.getPosition,
            p = c.getLimit,
            f = c.exceededLimit,
            v = c.translate,
            g = e.is(eh),
            m = 1;
          function y(t, e, n, a, l) {
            var p = h();
            if ((S(), n && (!g || !f()))) {
              var v = i.Layout.sliderSize(),
                y = to(t) * v * Z(te(t) / v) || 0;
              t = c.toPosition(i.Controller.toDest(t % v)) + y;
            }
            var E,
              L,
              C = ((E = p), (L = t), 1 > te(E - L));
            (m = 1),
              (e = C ? 0 : e || Q(te(t - p) / 1.5, 800)),
              (r = a),
              (o = tA(e, b, s($, p, t, l), 1)),
              u(5),
              d(tb),
              o.start();
          }
          function b() {
            u(3), r && r(), d(t$);
          }
          function $(t, e, i, s) {
            var o,
              a,
              l = h(),
              d =
                (t +
                  (e - t) *
                    ((o = s),
                    (a = n.easingFunc),
                    a ? a(o) : 1 - Math.pow(1 - o, 4)) -
                  l) *
                m;
            v(l + d),
              g &&
                !i &&
                f() &&
                ((m *= 0.6), 10 > te(d) && y(p(f(!0)), 600, !1, r, !0));
          }
          function S() {
            o && o.cancel();
          }
          function E() {
            o && !o.isPaused() && (S(), b());
          }
          return {
            mount: function t() {
              l(th, S), l([tg, tv], E);
            },
            destroy: S,
            scroll: y,
            cancel: E,
          };
        },
        Drag: function t(e, i, s) {
          var n,
            r,
            a,
            d,
            u,
            c,
            h,
            p,
            f = tx(e),
            v = f.on,
            g = f.emit,
            m = f.bind,
            y = f.unbind,
            b = e.state,
            $ = i.Move,
            S = i.Scroll,
            E = i.Controller,
            C = i.Elements.track,
            _ = i.Media.reduce,
            x = i.Direction,
            A = x.resolve,
            k = x.orient,
            w = $.getPosition,
            M = $.exceededLimit,
            B = !1;
          function P() {
            var t,
              e = s.drag;
            (h = t = !e), (d = "free" === e);
          }
          function T(t) {
            if (((c = !1), !h)) {
              var e,
                i,
                n = F(t);
              (e = t.target),
                (i = s.noDrag),
                L(e, "." + tJ + ", ." + tY) ||
                  (i && L(e, i)) ||
                  (!n && t.button) ||
                  (E.isBusy()
                    ? z(t, !0)
                    : ((p = n ? C : window),
                      (u = b.is([4, 5])),
                      (a = null),
                      m(p, eu, q, eg),
                      m(p, ec, D, eg),
                      $.cancel(),
                      S.cancel(),
                      O(t)));
            }
          }
          function q(t) {
            if ((b.is(6) || (b.set(6), g("drag")), t.cancelable)) {
              if (u) {
                $.translate(n + ((p = H(t)), p / (B && e.is(eh) ? 5 : 1)));
                var i,
                  o,
                  r,
                  a,
                  d,
                  h,
                  p,
                  f = N(t) > 200,
                  v = B !== (B = M());
                (f || v) && O(t), (c = !0), g("dragging"), z(t);
              } else {
                (i = t),
                  te(H(i)) > te(H(i, !0)) &&
                    ((u =
                      ((o = t),
                      (r = s.dragMinThreshold),
                      (a = l(r)),
                      (d = (a && r.mouse) || 0),
                      (h = (a ? r.touch : +r) || 10),
                      te(H(o)) > (F(o) ? h : d))),
                    z(t));
              }
            }
          }
          function D(t) {
            var n, o, r, a, l;
            b.is(6) && (b.set(3), g("dragged")),
              u &&
                ((a =
                  ((o = r =
                    (function t(i) {
                      if (e.is(ep) || !B) {
                        var s = N(i);
                        if (s && s < 200) return H(i) / s;
                      }
                      return 0;
                    })((n = t))),
                  w() +
                    to(o) *
                      J(
                        te(o) * (s.flickPower || 600),
                        d ? 1 / 0 : i.Layout.listSize() * (s.flickMaxPages || 1)
                      ))),
                (l = s.rewind && s.rewindByDrag),
                _(!1),
                d
                  ? E.scroll(a, 0, s.snap)
                  : e.is(ef)
                  ? E.go(0 > k(to(r)) ? (l ? "<" : "-") : l ? ">" : "+")
                  : e.is(eh) && B && l
                  ? E.go(M(!0) ? ">" : "<")
                  : E.go(E.toDest(a), !0),
                _(!0),
                z(t)),
              y(p, eu, q),
              y(p, ec, D),
              (u = !1);
          }
          function I(t) {
            !h && c && z(t, !0);
          }
          function O(t) {
            (a = r), (r = t), (n = w());
          }
          function H(t, e) {
            return R(t, e) - R(W(t), e);
          }
          function N(t) {
            return V(t) - V(W(t));
          }
          function W(t) {
            return (r === t && a) || r;
          }
          function R(t, e) {
            return (F(t) ? t.changedTouches[0] : t)["page" + A(e ? "Y" : "X")];
          }
          function F(t) {
            return "undefined" != typeof TouchEvent && t instanceof TouchEvent;
          }
          function X() {
            return u;
          }
          function G(t) {
            h = t;
          }
          return {
            mount: function t() {
              m(C, eu, o, eg),
                m(C, ec, o, eg),
                m(C, ed, T, eg),
                m(C, "click", I, { capture: !0 }),
                m(C, "dragstart", z),
                v([tu, tg], P);
            },
            disable: G,
            isDragging: X,
          };
        },
        Keyboard: function t(e, i, s) {
          var o,
            r,
            a = tx(e),
            l = a.on,
            d = a.bind,
            u = a.unbind,
            c = e.root,
            h = i.Direction.resolve;
          function p() {
            var t = s.keyboard;
            t && d((o = "global" === t ? window : c), eb, m);
          }
          function f() {
            u(o, eb);
          }
          function v(t) {
            r = t;
          }
          function g() {
            var t = r;
            (r = !0),
              n(function () {
                r = t;
              });
          }
          function m(t) {
            if (!r) {
              var i = ey(t);
              i === h(tw) ? e.go("<") : i === h(tM) && e.go(">");
            }
          }
          return {
            mount: function t() {
              p(), l(tg, f), l(tg, p), l(th, g);
            },
            destroy: f,
            disable: v,
          };
        },
        LazyLoad: function t(i, n, o) {
          var r = tx(i),
            a = r.on,
            l = r.off,
            d = r.bind,
            u = r.emit,
            c = "sequential" === o.lazyLoad,
            h = [tp, t$],
            p = [];
          function f() {
            e(p),
              n.Slides.forEach(function (t) {
                X(t.slide, eE).forEach(function (e) {
                  var i = O(e, e$),
                    s = O(e, eS);
                  if (i !== e.src || s !== e.srcset) {
                    var n = o.classes.spinner,
                      r = e.parentElement,
                      a = _(r, "." + n) || T("span", n, r);
                    p.push([e, t, a]), e.src || D(e, "none");
                  }
                });
              }),
              c ? y() : (l(h), a(h, v), v());
          }
          function v() {
            (p = p.filter(function (t) {
              var e = o.perPage * ((o.preloadPages || 1) + 1) - 1;
              return !t[1].isWithin(i.index, e) || g(t);
            })).length || l(h);
          }
          function g(t) {
            var e = t[0];
            $(t[1].slide, eo),
              d(e, "load error", s(m, t)),
              P(e, "src", O(e, e$)),
              P(e, "srcset", O(e, eS)),
              B(e, e$),
              B(e, eS);
          }
          function m(t, e) {
            var i = t[0],
              s = t[1];
            G(s.slide, eo),
              "error" !== e.type && (W(t[2]), D(i, ""), u(t_, i, s), u(tm)),
              c && y();
          }
          function y() {
            p.length && g(p.shift());
          }
          return {
            mount: function t() {
              o.lazyLoad && (f(), a(tv, f));
            },
            destroy: s(e, p),
            check: v,
          };
        },
        Pagination: function t(n, o, r) {
          var a,
            l,
            d = tx(n),
            u = d.on,
            c = d.emit,
            h = d.bind,
            p = o.Slides,
            f = o.Elements,
            v = o.Controller,
            g = v.hasFocus,
            m = v.getIndex,
            y = v.go,
            b = o.Direction.resolve,
            S = f.pagination,
            E = [];
          function L() {
            C(), u([tg, tv, "ei"], L);
            var t = r.pagination;
            S && D(S, t ? "" : "none"),
              t &&
                (u([th, tb, t$], w),
                (function t() {
                  var e = n.length,
                    i = r.classes,
                    o = r.i18n,
                    d = r.perPage,
                    u = g() ? v.getEnd() + 1 : tt(e / d);
                  (a = S || T("ul", i.pagination, f.track.parentElement)),
                    $(a, (l = t5 + "--" + A())),
                    P(a, tT, "tablist"),
                    P(a, tN, o.select),
                    P(a, t2, "ttb" === A() ? "vertical" : "");
                  for (var c = 0; c < u; c++) {
                    var m = T("li", null, a),
                      y = T("button", { class: i.page, type: "button" }, m),
                      b = p.getIn(c).map(function (t) {
                        return t.slide.id;
                      }),
                      L = !g() && d > 1 ? o.pageX : o.slideX;
                    h(y, "click", s(_, c)),
                      r.paginationKeyboard && h(y, "keydown", s(x, c)),
                      P(m, tT, "presentation"),
                      P(y, tT, "tab"),
                      P(y, tI, b.join(" ")),
                      P(y, tN, tr(L, c + 1)),
                      P(y, tq, -1),
                      E.push({ li: m, button: y, page: c });
                  }
                })(),
                w(),
                c("pagination:mounted", { list: a, items: E }, k(n.index)));
          }
          function C() {
            a && (W(S ? i(a.children) : a), G(a, l), e(E), (a = null)),
              d.destroy();
          }
          function _(t) {
            y(">" + t, !0);
          }
          function x(t, e) {
            var i = E.length,
              s = ey(e),
              n = A(),
              o = -1;
            s === b(tM, !1, n)
              ? (o = ++t % i)
              : s === b(tw, !1, n)
              ? (o = (--t + i) % i)
              : "Home" === s
              ? (o = 0)
              : "End" === s && (o = i - 1);
            var r = E[o];
            r && (I(r.button), y(">" + o), z(e, !0));
          }
          function A() {
            return r.paginationDirection || r.direction;
          }
          function k(t) {
            return E[v.toPage(t)];
          }
          function w() {
            var t = k(m(!0)),
              e = k(m());
            if (t) {
              var i = t.button;
              G(i, ee), B(i, tH), P(i, tq, -1);
            }
            if (e) {
              var s = e.button;
              $(s, ee), P(s, tH, !0), P(s, tq, "");
            }
            c("pagination:updated", { list: a, items: E }, t, e);
          }
          return { items: E, mount: L, destroy: C, getAt: k, update: w };
        },
        Sync: function t(i, n, o) {
          var r = o.isNavigation,
            a = o.slideFocus,
            l = [];
          function d() {
            var t, e;
            i.splides.forEach(function (t) {
              t.isParent || (c(i, t.splide), c(t.splide, i));
            }),
              r &&
                ((t = tx(i)),
                (e = t.on),
                e(tf, f),
                e("sk", v),
                e([tu, tg], p),
                l.push(t),
                t.emit(tE, i.splides));
          }
          function u() {
            l.forEach(function (t) {
              t.destroy();
            }),
              e(l);
          }
          function c(t, e) {
            var i = tx(t);
            i.on(th, function (t, i, s) {
              e.go(e.is(ep) ? s : t);
            }),
              l.push(i);
          }
          function p() {
            P(n.Elements.list, t2, "ttb" === o.direction ? "vertical" : "");
          }
          function f(t) {
            i.go(t.index);
          }
          function v(t, e) {
            m(eL, ey(e)) && (f(t), z(e));
          }
          return {
            setup: s(n.Media.set, { slideFocus: h(a) ? r : a }, !0),
            mount: d,
            destroy: u,
            remount: function t() {
              u(), d();
            },
          };
        },
        Wheel: function t(e, i, s) {
          var n = tx(e).bind,
            o = 0;
          function r(t) {
            if (t.cancelable) {
              var n,
                r = t.deltaY,
                a = r < 0,
                l = V(t),
                d = s.wheelMinThreshold || 0,
                u = s.wheelSleep || 0;
              te(r) > d && l - o > u && (e.go(a ? "<" : ">"), (o = l)),
                (n = a),
                (!s.releaseWheel ||
                  e.state.is(4) ||
                  -1 !== i.Controller.getAdjacent(n)) &&
                  z(t);
            }
          }
          return {
            mount: function t() {
              s.wheel && n(i.Elements.track, "wheel", r, eg);
            },
          };
        },
        Live: function t(e, i, n) {
          var o = tx(e).on,
            r = i.Elements.track,
            a = n.live && !n.isNavigation,
            l = T("span", et),
            d = tA(90, s(u, !1));
          function u(t) {
            P(r, tF, t), t ? (S(r, l), d.start()) : (W(l), d.cancel());
          }
          function c(t) {
            a && P(r, t0, t ? "off" : "polite");
          }
          return {
            mount: function t() {
              a &&
                (c(!i.Autoplay.isPaused()),
                P(r, t3, !0),
                (l.textContent = "â€¦"),
                o(tL, s(c, !0)),
                o(tC, s(c, !1)),
                o([tp, t$], s(u, !0)));
            },
            disable: c,
            destroy: function t() {
              B(r, [t0, t3, tF]), W(l);
            },
          };
        },
      }),
      e_ = {
        type: "slide",
        role: "region",
        speed: 400,
        perPage: 1,
        cloneStatus: !0,
        arrows: !0,
        pagination: !0,
        paginationKeyboard: !0,
        interval: 5e3,
        pauseOnHover: !0,
        pauseOnFocus: !0,
        resetProgress: !0,
        easing: "cubic-bezier(0.25, 1, 0.5, 1)",
        drag: !0,
        direction: "ltr",
        trimSpace: !0,
        focusableNodes: "a, button, textarea, input, select, iframe",
        live: !0,
        classes: {
          slide: tV,
          clone: tU,
          arrows: t6,
          arrow: tY,
          prev: t7,
          next: tK,
          pagination: t5,
          page: tJ,
          spinner: t1 + "spinner",
        },
        i18n: {
          prev: "Previous slide",
          next: "Next slide",
          first: "Go to first slide",
          last: "Go to last slide",
          slideX: "Go to slide %s",
          pageX: "Go to page %s",
          play: "Start autoplay",
          pause: "Pause autoplay",
          carousel: "carousel",
          slide: "slide",
          select: "Select a slide to show",
          slideLabel: "%s of %s",
        },
        reducedMotion: { speed: 0, rewindSpeed: 0, autoplay: "pause" },
      };
    function ex(t, e, i) {
      var s = e.Slides;
      function r() {
        s.forEach(function (t) {
          t.style("transform", "translateX(-" + 100 * t.index + "%)");
        });
      }
      return {
        mount: function e() {
          tx(t).on([tu, tv], r);
        },
        start: function t(e, o) {
          s.style("transition", "opacity " + i.speed + "ms " + i.easing), n(o);
        },
        cancel: o,
      };
    }
    function eA(t, e, i) {
      var n,
        o = e.Move,
        r = e.Controller,
        a = e.Scroll,
        l = e.Elements.list,
        d = s(q, l, "transition");
      function u() {
        d(""), a.cancel();
      }
      return {
        mount: function e() {
          tx(t).bind(l, "transitionend", function (t) {
            t.target === l && n && (u(), n());
          });
        },
        start: function e(s, l) {
          var u = o.toPosition(s, !0),
            c = o.getPosition(),
            h = (function e(s) {
              var n = i.rewindSpeed;
              if (t.is(eh) && n) {
                var o = r.getIndex(!0),
                  a = r.getEnd();
                if ((0 === o && s >= a) || (o >= a && 0 === s)) return n;
              }
              return i.speed;
            })(s);
          te(u - c) >= 1 && h >= 1
            ? i.useScroll
              ? a.scroll(u, h, !1, l)
              : (d("transform " + h + "ms " + i.easing),
                o.translate(u, !0),
                (n = l))
            : (o.jump(s), l());
        },
        cancel: u,
      };
    }
    var ek = (function () {
      function t(e, i) {
        (this.event = tx()),
          (this.Components = {}),
          (this.state = (function t(e) {
            var i = 1;
            function s(t) {
              i = t;
            }
            return {
              set: s,
              is: function t(e) {
                return m(v(e), i);
              },
            };
          })(1)),
          (this.splides = []),
          (this._o = {}),
          (this._E = {});
        var s = c(e) ? F(document, e) : e;
        K(s, s + " is invalid."),
          (this.root = s),
          (i = w(
            { label: O(s, tN) || "", labelledby: O(s, tW) || "" },
            e_,
            t.defaults,
            i || {}
          ));
        try {
          w(i, JSON.parse(O(s, Y)));
        } catch (n) {
          K(!1, "Invalid JSON");
        }
        this._o = Object.create(w({}, i));
      }
      var s = t.prototype;
      return (
        (s.mount = function t(e, i) {
          var s = this,
            n = this.state,
            o = this.Components;
          K(n.is([1, 7]), "Already mounted!"),
            n.set(1),
            (this._C = o),
            (this._T = i || this._T || (this.is(ef) ? ex : eA)),
            (this._E = e || this._E);
          var r = k({}, eC, this._E, { Transition: this._T });
          return (
            A(r, function (t, e) {
              var i = t(s, o, s._o);
              (o[e] = i), i.setup && i.setup();
            }),
            A(o, function (t) {
              t.mount && t.mount();
            }),
            this.emit(tu),
            $(this.root, "is-initialized"),
            n.set(3),
            this.emit(tc),
            this
          );
        }),
        (s.sync = function t(e) {
          return (
            this.splides.push({ splide: e }),
            e.splides.push({ splide: this, isParent: !0 }),
            this.state.is(3) &&
              (this._C.Sync.remount(), e.Components.Sync.remount()),
            this
          );
        }),
        (s.go = function t(e) {
          return this._C.Controller.go(e), this;
        }),
        (s.on = function t(e, i) {
          return this.event.on(e, i), this;
        }),
        (s.off = function t(e) {
          return this.event.off(e), this;
        }),
        (s.emit = function t(e) {
          var s;
          return (
            (s = this.event).emit.apply(s, [e].concat(i(arguments, 1))), this
          );
        }),
        (s.add = function t(e, i) {
          return this._C.Slides.add(e, i), this;
        }),
        (s.remove = function t(e) {
          return this._C.Slides.remove(e), this;
        }),
        (s.is = function t(e) {
          return this._o.type === e;
        }),
        (s.refresh = function t() {
          return this.emit(tv), this;
        }),
        (s.destroy = function t(i) {
          void 0 === i && (i = !0);
          var s = this.event,
            n = this.state;
          return (
            n.is(1)
              ? tx(this).on(tc, this.destroy.bind(this, i))
              : (A(
                  this._C,
                  function (t) {
                    t.destroy && t.destroy(i);
                  },
                  !0
                ),
                s.emit(tS),
                s.destroy(),
                i && e(this.splides),
                n.set(7)),
            this
          );
        }),
        _createClass(t, [
          {
            key: "options",
            get: function t() {
              return this._o;
            },
            set: function t(e) {
              this._C.Media.set(e, !0, !0);
            },
          },
          {
            key: "length",
            get: function t() {
              return this._C.Slides.getLength(!0);
            },
          },
          {
            key: "index",
            get: function t() {
              return this._C.Controller.getIndex();
            },
          },
        ]),
        t
      );
    })();
    return (
      (ek.defaults = {}),
      (ek.STATES = {
        CREATED: 1,
        MOUNTED: 2,
        IDLE: 3,
        MOVING: 4,
        SCROLLING: 5,
        DRAGGING: 6,
        DESTROYED: 7,
      }),
      ek
    );
  });
class SplideComponent extends HTMLElement {
  constructor() {
    super(),
      (this.sliderContainer = this.querySelector(".splide")),
      document.addEventListener("shopify:section:load", (t) => {
        this.initSlider();
      });
  }
  connectedCallback() {
    this.initSlider();
  }
  initSlider() {
    (this.type = this.dataset.type || "slide"),
      (this.typeMobile = this.dataset.typeMobile || this.type),
      (this.direction = this.dataset.direction || "ltr"),
      (this.rewind = "fade" === this.type),
      (this.autoplay = "true" === this.dataset.autoplay),
      (this.autoplaySpeed =
        this.dataset.autoplaySpeed &&
        !isNaN(parseInt(this.dataset.autoplaySpeed))
          ? 1e3 * parseInt(this.dataset.autoplaySpeed)
          : 5e3),
      (this.drag =
        "false" !== this.dataset.drag &&
        ("free" !== this.dataset.drag || "free")),
      (this.focus = this.dataset.focus || 0),
      (this.trimSpace = "false" !== this.dataset.trimSpace),
      (this.arrows = "false" !== this.dataset.arrows),
      (this.arrowsColor = this.dataset.arrowsColor
        ? ` color-${this.dataset.arrowsColor}`
        : ""),
      (this.pagination = "false" !== this.dataset.pagination),
      (this.omitEnd = "false" !== this.dataset.omitEnd),
      (this.dotsColor = this.dataset.dotsColor
        ? ` color-${this.dataset.dotsColor} dots-custom-color`
        : ""),
      (this.slidesDesktop =
        this.dataset.slidesDesktop &&
        !isNaN(parseInt(this.dataset.slidesDesktop))
          ? parseInt(this.dataset.slidesDesktop)
          : 3),
      (this.autoWidth = "true" === this.dataset.autoWidth),
      (this.slidesMobile =
        this.dataset.slidesMobile && !isNaN(parseInt(this.dataset.slidesMobile))
          ? parseInt(this.dataset.slidesMobile)
          : 1),
      (this.perMoveDesktop =
        this.dataset.perMoveDesktop &&
        !isNaN(parseInt(this.dataset.perMoveDesktop))
          ? parseInt(this.dataset.perMoveDesktop)
          : 1),
      (this.perMoveMobile =
        this.dataset.perMoveMobile &&
        !isNaN(parseInt(this.dataset.perMoveMobile))
          ? parseInt(this.dataset.perMoveMobile)
          : 1),
      (this.gapDesktop = this.dataset.gapDesktop
        ? parseInt(this.dataset.gapDesktop)
        : 30),
      (this.gapMobile = this.dataset.gapMobile
        ? parseInt(this.dataset.gapMobile)
        : 15),
      (this.paddingCalcDesktop = "true" === this.dataset.paddingCalcDesktop),
      (this.rightPaddingDesktop =
        parseInt(this.dataset.sidePaddingDesktop) || 0),
      (this.leftPaddingDesktop = this.dataset.paddingCalcDesktop
        ? 0
        : this.rightPaddingDesktop),
      (this.paddingCalcMobile = "true" === this.dataset.paddingCalcMobile),
      (this.rightPaddingMobile = parseInt(this.dataset.sidePaddingMobile) || 0),
      (this.leftPaddingMobile = this.paddingCalcMobile
        ? 0
        : this.rightPaddingMobile),
      (this.destroyDesktop = "true" === this.dataset.destroyDesktop),
      (this.destroyMobile = "true" === this.dataset.destroyMobile),
      (this.config = {
        type: this.type,
        direction: this.direction,
        rewind: this.rewind,
        autoplay: this.autoplay,
        interval: this.autoplaySpeed,
        drag: this.drag,
        focus: this.focus,
        trimSpace: this.trimSpace,
        arrows: this.arrows,
        pagination: this.pagination,
        omitEnd: this.omitEnd,
        perPage: this.slidesDesktop,
        perMove: this.perMoveDesktop,
        autoWidth: this.autoWidth,
        gap: this.gapDesktop,
        paddingCalc: this.paddingCalcDesktop,
        padding: {
          left: this.leftPaddingDesktop,
          right: this.rightPaddingDesktop,
        },
        destroy: this.destroyDesktop,
        classes: {
          arrow: `splide__arrow${this.arrowsColor}`,
          page: `splide__pagination__page${this.dotsColor}`,
        },
        easing: "cubic-bezier(0.25, 1, 0.5, 1)",
        breakpoints: {
          749: {
            type: this.typeMobile,
            perPage: this.slidesMobile,
            perMove: this.perMoveMobile,
            gap: this.gapMobile,
            paddingCalc: this.paddingCalcMobile,
            padding: {
              left: this.leftPaddingMobile,
              right: this.rightPaddingMobile,
            },
            destroy: this.destroyMobile,
          },
        },
      });
    let t = new Splide(this.sliderContainer, this.config);
    t.on("mounted", () => {
      let e = t.index,
        i = t.Components.Elements.slides[e];
      if (i) {
        let s = i.querySelector("img");
        s
          ? s.complete
            ? (i.classList.add("is-instant-active"),
              this.setActiveSlideHeight(i))
            : s.addEventListener("load", () => {
                i.classList.add("is-instant-active"),
                  this.setActiveSlideHeight(i);
              })
          : (i.classList.add("is-instant-active"),
            this.setActiveSlideHeight(i));
      }
      let n = debounce(() => {
        let e = t.Components.Elements.slides[t.index];
        this.setActiveSlideHeight(e);
      }, 200);
      window.addEventListener("resize", n);
    }),
      t.on("move", (e) => {
        let i = t.index,
          s = t.Components.Elements.slides;
        if (s) {
          let n = s[i];
          n &&
            (s.forEach((t) => t.classList.remove("is-instant-active")),
            n.classList.add("is-instant-active"),
            this.setActiveSlideHeight(n));
        }
      }),
      "true" === this.dataset.imageSlider &&
        window.addEventListener("load", () => {
          let e = t.Components.Elements.slides[t.index];
          this.setActiveSlideHeight(e);
        }),
      t.mount();
  }
  setActiveSlideHeight(t) {
    if (t) {
      let e = t.offsetHeight;
      this.style.setProperty("--active-slide-height", `${e}px`);
    }
  }
}
customElements.define("splide-component", SplideComponent);
class DetailsDisclosure extends HTMLElement {
  constructor() {
    super(),
      (this.mainDetailsToggle = this.querySelector("details")),
      (this.content =
        this.mainDetailsToggle.querySelector("summary").nextElementSibling),
      this.mainDetailsToggle.addEventListener(
        "focusout",
        this.onFocusOut.bind(this)
      ),
      this.mainDetailsToggle.addEventListener(
        "toggle",
        this.onToggle.bind(this)
      );
  }
  onFocusOut() {
    setTimeout(() => {
      this.contains(document.activeElement) || this.close();
    });
  }
  onToggle() {
    this.animations || (this.animations = this.content.getAnimations()),
      this.mainDetailsToggle.hasAttribute("open")
        ? this.animations.forEach((t) => t.play())
        : this.animations.forEach((t) => t.cancel());
  }
  close() {
    this.mainDetailsToggle.removeAttribute("open"),
      this.mainDetailsToggle
        .querySelector("summary")
        .setAttribute("aria-expanded", !1);
  }
}
customElements.define("details-disclosure", DetailsDisclosure);
class HeaderMenu extends DetailsDisclosure {
  constructor() {
    super(), (this.header = document.querySelector(".header-wrapper"));
  }
  onToggle() {
    this.header &&
      ((this.header.preventHide = this.mainDetailsToggle.open),
      "" ===
        document.documentElement.style.getPropertyValue(
          "--header-bottom-position-desktop"
        ) &&
        document.documentElement.style.setProperty(
          "--header-bottom-position-desktop",
          `${Math.floor(this.header.getBoundingClientRect().bottom)}px`
        ));
  }
}
customElements.define("header-menu", HeaderMenu);
class DetailsModal extends HTMLElement {
  constructor() {
    super(),
      (this.detailsContainer = this.querySelector("details")),
      (this.summaryToggle = this.querySelector("summary")),
      this.detailsContainer.addEventListener(
        "keyup",
        (t) => "ESCAPE" === t.code.toUpperCase() && this.close()
      ),
      this.summaryToggle.addEventListener(
        "click",
        this.onSummaryClick.bind(this)
      ),
      this.querySelector('button[type="button"]').addEventListener(
        "click",
        this.close.bind(this)
      ),
      this.summaryToggle.setAttribute("role", "button");
  }
  isOpen() {
    return this.detailsContainer.hasAttribute("open");
  }
  onSummaryClick(t) {
    t.preventDefault(),
      t.target.closest("details").hasAttribute("open")
        ? this.close()
        : this.open(t);
  }
  onBodyClick(t) {
    (!this.contains(t.target) ||
      t.target.classList.contains("modal-overlay")) &&
      this.close(!1);
  }
  open(t) {
    (this.onBodyClickEvent =
      this.onBodyClickEvent || this.onBodyClick.bind(this)),
      t.target.closest("details").setAttribute("open", !0),
      document.body.addEventListener("click", this.onBodyClickEvent),
      document.body.classList.add("overflow-hidden"),
      trapFocus(
        this.detailsContainer.querySelector('[tabindex="-1"]'),
        this.detailsContainer.querySelector('input:not([type="hidden"])')
      );
  }
  close(t = !0) {
    removeTrapFocus(t ? this.summaryToggle : null),
      this.detailsContainer.removeAttribute("open"),
      document.body.removeEventListener("click", this.onBodyClickEvent),
      document.body.classList.remove("overflow-hidden");
  }
}
customElements.define("details-modal", DetailsModal);
let hotspotButtons = [];
function registerHotspotButton(t) {
  hotspotButtons.push(t);
}
function unregisterHotspotButton(t) {
  let e = hotspotButtons.indexOf(t);
  -1 !== e && hotspotButtons.splice(e, 1);
}
document.addEventListener("mousedown", function (t) {
  for (let e of hotspotButtons)
    "true" !== e.dataset.open || e.contains(t.target) || e.closeModal();
});
class HotspotButton extends HTMLElement {
  constructor() {
    super(),
      (this.button = this.querySelector(".hotspot-btn")),
      (this.content = this.querySelector(".hotspot__content")),
      (this.type = this.dataset.type),
      (this.openEvent = this.dataset.openEvent),
      (this.header = document.querySelector(".section-header")),
      (this.stickyHeader = document.querySelector("sticky-header")),
      (this.mobileOverlay = this.querySelector(".hotspot-overlay")),
      this.button.addEventListener("click", this.toggleModal.bind(this)),
      "hover" === this.openEvent &&
        (this.button.addEventListener("mouseover", this.openModal.bind(this)),
        this.button.addEventListener(
          "mouseout",
          this.startCheckingMouseLeave.bind(this)
        ),
        this.content.addEventListener(
          "mouseover",
          this.stopCheckingMouseLeave.bind(this)
        ),
        this.content.addEventListener(
          "mouseout",
          this.startCheckingMouseLeave.bind(this)
        )),
      this.mobileOverlay &&
        this.mobileOverlay.addEventListener(
          "click",
          this.closeModal.bind(this)
        );
  }
  startCheckingMouseLeave() {
    (this.checkingMouseLeave = !0),
      setTimeout(() => {
        this.checkingMouseLeave && this.closeModal();
      }, 200);
  }
  stopCheckingMouseLeave() {
    this.checkingMouseLeave = !1;
  }
  toggleModal() {
    "true" === this.dataset.open ? this.closeModal() : this.openModal();
  }
  openModal() {
    let t = this.header.clientHeight;
    (this.header.classList.contains("shopify-section-header-hidden") ||
      !this.stickyHeader) &&
      (t = 0);
    this.content.getBoundingClientRect().top - t < 0 &&
      (this.dataset.direction = "bottom"),
      (this.dataset.open = "true");
  }
  closeModal() {
    (this.dataset.open = "false"),
      setTimeout(() => {
        this.dataset.direction = "";
      }, 100);
  }
  connectedCallback() {
    registerHotspotButton(this);
  }
  disconnectedCallback() {
    unregisterHotspotButton(this);
  }
}
customElements.define("hotspot-button", HotspotButton);
class ParallaxHero extends HTMLElement {
  constructor() {
    super(),
      (this.overlays = this.querySelectorAll(".parallax-hero__layer")),
      this.handleScroll(),
      window.addEventListener("scroll", () =>
        requestAnimationFrame(this.handleScroll.bind(this))
      );
  }
  handleScroll(t) {
    var { top: e, left: i, height: s } = this.getBoundingClientRect();
    if (e > window.innerHeight || (e >= 0 ? (e = 0) : (e *= -1), e > s)) return;
    let n = e / s;
    this.overlays.forEach((t) => {
      let i = e * (parseInt(t.dataset.scrollY) / 100),
        s = parseInt(t.dataset.scrollX) * n,
        o = 100 + (parseInt(t.dataset.zoom) - 100) * n,
        r = 3.6 * parseInt(t.dataset.rotation) * n;
      t.style.transform = `translateY(${i}px) translateX(${s}%) scale(${
        o / 100
      }) rotate(${r}deg)`;
    });
  }
}
customElements.define("parallax-hero", ParallaxHero);
class ContentTabs extends HTMLElement {
  constructor() {
    super(),
      (this.buttons = this.querySelectorAll(".content-tab-button")),
      (this.tabs = this.querySelectorAll(".content-tab")),
      (this.tabsContainer = this.querySelector(".section-content-tabs__tabs")),
      (this.activeButton = this.querySelector(".content-tab-button--active")),
      (this.activeTab = this.querySelector(".content-tab--active")),
      (this.isMovingAnimation = "moving" === this.dataset.animation),
      this.isMovingAnimation &&
        ((this.activeBg = this.querySelector(".content-tab-buttom__active-bg")),
        this.handleActiveBg(),
        (this.activeBg.style.transitionDuration = "0.4s")),
      this.setHeight(),
      this.buttons.forEach((t) => {
        t.addEventListener("click", this.handleClick.bind(this));
      }),
      window.addEventListener("resize", () => {
        this.setHeight(), this.isMovingAnimation && this.handleActiveBg();
      });
  }
  handleClick(t) {
    (this.activeButton = t.currentTarget),
      this.buttons.forEach((t) => {
        t.classList.remove("content-tab-button--active");
      }),
      this.activeButton.classList.add("content-tab-button--active"),
      this.tabs.forEach((t) => {
        t.classList.remove("content-tab--active"),
          t.dataset.index === this.activeButton.dataset.index &&
            (this.activeTab = t);
      }),
      this.activeTab.classList.add("content-tab--active"),
      this.setHeight(),
      this.isMovingAnimation && this.handleActiveBg();
  }
  setHeight() {
    this.activeTab &&
      (this.tabsContainer.style.height = this.activeTab.clientHeight + "px");
  }
  handleActiveBg() {
    (this.activeBg.style.width =
      this.activeButton.getBoundingClientRect().width + "px"),
      (this.activeBg.style.height =
        this.activeButton.getBoundingClientRect().height + "px"),
      (this.activeBg.style.top = this.activeButton.offsetTop + "px"),
      (this.activeBg.style.left = this.activeButton.offsetLeft + "px");
  }
}
customElements.define("section-content-tabs", ContentTabs);
class InstaStories extends HTMLElement {
  constructor() {
    super(),
      (this.openButtons = this.querySelectorAll(".insta-story-open-btn")),
      (this.openButtonsOverflowContainer = this.querySelector(
        ".instagram-stories__open-buttons-container"
      )),
      (this.openButtonsContainer = this.querySelector(
        ".instagram-stories__open-buttons"
      )),
      (this.openBtnsPrev = this.querySelector(
        ".instagram-stories__open-btns-prev"
      )),
      (this.openBtnsNext = this.querySelector(
        ".instagram-stories__open-btns-next"
      )),
      (this.closeButtons = this.querySelectorAll(
        ".instagram-stories__close-button"
      )),
      (this.modal = this.querySelector(".instagram-stories__modal")),
      (this.modalOpen = !1),
      (this.slider = this.querySelector(".instagram-stories__slider")),
      (this.stories = this.querySelectorAll(".insta-story")),
      (this.prevBtns = this.querySelectorAll(".insta-story__prev")),
      (this.nextBtns = this.querySelectorAll(".insta-story__next")),
      (this.slideBtns = this.querySelectorAll(".insta-story__slide-btn")),
      (this.activeIndex = 0),
      (this.activeStory = this.stories[this.activeIndex]),
      (this.lastIndex = parseInt(this.dataset.lastIndex)),
      (this.pauseResumeBtns = this.querySelectorAll(
        ".insta-story__pause-resume-btn"
      )),
      (this.isPaused = !1),
      (this.volumeBtns = this.querySelectorAll(".insta-story__volume-btn")),
      (this.isMuted = !0),
      this.initStories(),
      this.initButtonsSlider(),
      this.openButtons.forEach((t) => {
        t.addEventListener("click", this.openModal.bind(this));
      }),
      this.closeButtons.forEach((t) => {
        t.addEventListener("click", this.closeModal.bind(this));
      }),
      this.prevBtns.forEach((t) => {
        t.addEventListener("click", this.storyPrevBtnClick.bind(this));
      }),
      this.nextBtns.forEach((t) => {
        t.addEventListener("click", this.storyNextBtnClick.bind(this));
      }),
      this.slideBtns.forEach((t) => {
        t.addEventListener("click", this.slideBtnClick.bind(this));
      }),
      this.pauseResumeBtns.forEach((t) => {
        t.addEventListener("click", this.togglePauseResume.bind(this));
      }),
      this.volumeBtns.forEach((t) => {
        t.addEventListener("click", this.toggleIsMuted.bind(this));
      }),
      this.slider.addEventListener(
        "touchstart",
        this.touchStartHandler.bind(this)
      ),
      this.slider.addEventListener("touchend", this.touchEndHandler.bind(this)),
      document.addEventListener("keydown", (t) => {
        if (this.modalOpen)
          switch (t.key) {
            case "Escape":
              this.closeModal();
              break;
            case "ArrowLeft":
              this.storyPrevBtnClick();
              break;
            case "ArrowRight":
              this.storyNextBtnClick();
          }
      }),
      Shopify.designMode &&
        (document.addEventListener("shopify:section:load", () => {
          this.initStories(), this.initButtonsSlider();
        }),
        document.addEventListener("shopify:section:reorder", () => {
          this.initStories(), this.initButtonsSlider();
        }));
  }
  autoplay() {
    let t = this.activeStory,
      e = parseInt(t.dataset.activeMediaIndex),
      i = t.querySelectorAll(".insta-story__media")[e],
      s = 1e3 * parseInt(i.getAttribute("data-duration"));
    this.updateProgressBars(e),
      (this.autoplayStartTime = Date.now()),
      (this.autoplayTimeout = setTimeout(() => {
        this.storyNextBtnClick();
      }, s));
  }
  storyPrevBtnClick() {
    let t = this.activeStory;
    "0" === t.dataset.activeMediaIndex
      ? this.changeActiveStory(this.activeIndex - 1)
      : this.changeActiveMedia(parseInt(t.dataset.activeMediaIndex) - 1);
  }
  storyNextBtnClick() {
    let t = this.activeStory;
    t.dataset.activeMediaIndex === t.dataset.lastMediaIndex
      ? this.changeActiveStory(this.activeIndex + 1)
      : this.changeActiveMedia(parseInt(t.dataset.activeMediaIndex) + 1);
  }
  slideBtnClick(t) {
    let e = parseInt(t.currentTarget.dataset.index);
    this.changeActiveStory(e);
  }
  changeActiveStory(t) {
    if ((clearTimeout(this.autoplayTimeout), t > this.lastIndex || t < 0))
      return;
    let e = this.stories[this.activeIndex],
      i = parseInt(e.dataset.activeMediaIndex);
    if ("true" === e.dataset.played || i > 0) {
      let s = e.querySelectorAll(".insta-story__progress-item")[i];
      s &&
        (s.classList.remove("insta-story__progress-item--active"),
        t > this.activeIndex &&
          s.classList.add("insta-story__progress-item--completed"));
    }
    let n = e.querySelectorAll(".insta-story__media")[i];
    if (n && "video" === n.getAttribute("data-type")) {
      let o = n.querySelector("video");
      o && (o.pause(), this.isPaused || (o.currentTime = 0));
    }
    (this.activeIndex = t),
      (this.activeStory = this.stories[this.activeIndex]),
      this.stories.forEach((t) => {
        t.classList.remove("insta-story--active");
      }),
      this.activeStory.classList.add("insta-story--active"),
      (this.activeStory.dataset.played = "true"),
      (this.slider.style.transform = `translateX(calc(var(--story-width) * ${
        -1 * this.activeIndex
      }))`);
    let r = parseInt(this.activeStory.dataset.activeMediaIndex, 10);
    this.changeActiveMedia(r), this.updateProgressBars(r);
  }
  changeActiveMedia(t) {
    if ((clearTimeout(this.autoplayTimeout), t < 0)) return;
    let e = this.activeStory,
      i = parseInt(e.dataset.lastMediaIndex);
    if (t > i) return;
    e.dataset.activeMediaIndex = t;
    let s = e.querySelectorAll(".insta-story__media");
    for (let n = 0; n < s.length; n++)
      if (n === t) {
        if (
          ((s[n].style.display = "block"),
          "video" === s[n].getAttribute("data-type"))
        ) {
          let o = s[n].querySelector("video");
          o && !this.isPaused && o.play();
        }
        e.querySelector(".insta-story__time-posted").innerHTML =
          s[n].dataset.timePosted;
      } else if (
        ((s[n].style.display = ""), "video" === s[n].getAttribute("data-type"))
      ) {
        let r = s[n].querySelector("video");
        r && (r.pause(), this.isPaused || (r.currentTime = 0));
      }
    this.updateProgressBars(t), this.isPaused || this.autoplay();
    let a = e.querySelectorAll(".insta-story__prev"),
      l = e.querySelectorAll(".insta-story__next");
    a.forEach((e) => {
      0 === this.activeIndex && 0 === t
        ? e.setAttribute("disabled", "")
        : e.removeAttribute("disabled");
    }),
      l.forEach((e) => {
        this.activeIndex === this.lastIndex && t === i
          ? e.setAttribute("disabled", "")
          : e.removeAttribute("disabled");
      });
  }
  updateProgressBars(t) {
    let e = this.activeStory,
      i = e.querySelectorAll(".insta-story__progress-item");
    i.forEach((e, i) => {
      e.classList.remove(
        "insta-story__progress-item--completed",
        "insta-story__progress-item--active"
      ),
        i < t
          ? e.classList.add("insta-story__progress-item--completed")
          : i === t && e.classList.add("insta-story__progress-item--active");
    });
  }
  openModal(t) {
    window.scrollBy(0, -1),
      (this.modal.dataset.open = "true"),
      (this.modalOpen = !0),
      document.body.classList.add("overflow-hidden"),
      this.changeActiveStory(parseInt(t.currentTarget.dataset.index));
  }
  closeModal(t) {
    this.querySelectorAll("video").forEach((t) => {
      t.pause();
    }),
      (this.modal.dataset.open = "false"),
      (this.modalOpen = !1),
      document.body.classList.remove("overflow-hidden"),
      clearTimeout(this.autoplayTimeout);
  }
  initButtonsSlider() {
    if (
      this.openButtonsOverflowContainer.clientWidth >
      this.openButtonsContainer.clientWidth
    )
      return;
    let t = () => "ontouchstart" in window || navigator.maxTouchPoints,
      e,
      i = 0,
      s = 0,
      n = (t) => {
        (this.openButtonsContainer.style.transform = `translateX(${t}px)`),
          (i = t);
      };
    this.openButtonsOverflowContainer.addEventListener("touchstart", (t) => {
      (this.isDragging = !0), (e = t.touches[0].clientX - s);
    }),
      this.openButtonsOverflowContainer.addEventListener("touchmove", (t) => {
        if (!this.isDragging) return;
        let i = t.touches[0].clientX,
          s = i - e;
        s < 0 &&
          Math.abs(s) <=
            this.openButtonsContainer.offsetWidth -
              this.openButtonsOverflowContainer.offsetWidth &&
          n(s);
      }),
      this.openButtonsOverflowContainer.addEventListener("touchend", () => {
        (this.isDragging = !1), (s = i);
      });
    let o = parseFloat(getComputedStyle(this.openButtons[0]).width),
      r = parseFloat(getComputedStyle(this.openButtonsContainer).columnGap),
      a = () => {
        let t = Math.floor(
          this.openButtonsOverflowContainer.clientWidth / (o + r)
        );
        return (t - 1) * (o + r);
      },
      l = () => {
        (this.openBtnsPrev.style.display =
          this.openButtonsOverflowContainer.scrollLeft <= 0 ? "none" : "grid"),
          (this.openBtnsNext.style.display =
            this.openButtonsOverflowContainer.scrollLeft >
            this.openButtonsOverflowContainer.scrollWidth -
              this.openButtonsContainer.clientWidth
              ? "none"
              : "grid");
      };
    this.openBtnsPrev.addEventListener("click", () => {
      this.openButtonsOverflowContainer.scrollBy({
        left: -a(),
        behavior: "smooth",
      }),
        setTimeout(l, 300);
    }),
      this.openBtnsNext.addEventListener("click", () => {
        this.openButtonsOverflowContainer.scrollBy({
          left: a(),
          behavior: "smooth",
        }),
          setTimeout(l, 300);
      }),
      l(),
      t() &&
        ((this.openBtnsPrev.style.display = "none"),
        (this.openBtnsNext.style.display = "none")),
      window.addEventListener(
        "resize",
        debounce(() => {
          this.openButtonsOverflowContainer.clientWidth <=
          this.openButtonsContainer.clientWidth
            ? t()
              ? ((this.openBtnsPrev.style.display = "none"),
                (this.openBtnsNext.style.display = "none"))
              : l()
            : ((this.openBtnsPrev.style.display = "none"),
              (this.openBtnsNext.style.display = "none"));
        }, 250)
      );
  }
  initStories() {
    this.stories.forEach((t) => {
      let e = t.querySelectorAll(".insta-story__media");
      (t.dataset.lastMediaIndex = e.length - 1), (t.dataset.played = "false");
      let i = t.querySelector(".insta-story__progress");
      for (let s = 0; s < e.length; s++) {
        let n = e[s].getAttribute("data-duration"),
          o = document.createElement("span");
        (o.className = "insta-story__progress-item"),
          o.style.setProperty("--duration", `${n}s`);
        let r = document.createElement("span");
        (r.className = "insta-story__progress-bar"),
          o.appendChild(r),
          i.appendChild(o);
      }
      let a = parseInt(t.dataset.activeMediaIndex);
      e[a] && (e[a].style.display = "block");
    });
  }
  togglePauseResume(t) {
    let e = "true" === t.currentTarget.getAttribute("data-paused");
    e ? this.resumeStory() : this.pauseStory(),
      this.pauseResumeBtns.forEach((t) => {
        t.setAttribute("data-paused", e ? "false" : "true");
      });
  }
  pauseStory() {
    this.isPaused = !0;
    let t = this.activeStory.querySelectorAll(".insta-story__media")[
        parseInt(this.activeStory.dataset.activeMediaIndex)
      ],
      e = 1e3 * parseInt(t.getAttribute("data-duration"));
    if (
      ((this.remainingTime = e - (Date.now() - this.autoplayStartTime)),
      clearTimeout(this.autoplayTimeout),
      "video" === t.getAttribute("data-type"))
    ) {
      let i = t.querySelector("video");
      i && i.pause();
    }
    let s = this.querySelectorAll(".insta-story__progress-bar");
    s.forEach((t) => {
      t.style.animationPlayState = "paused";
    });
  }
  resumeStory() {
    this.isPaused = !1;
    let t = this.querySelectorAll(".insta-story__progress-bar");
    t.forEach((t) => {
      t.style.animationPlayState = "running";
    });
    let e = this.activeStory.querySelectorAll(".insta-story__media")[
      parseInt(this.activeStory.dataset.activeMediaIndex)
    ];
    if ("video" === e.getAttribute("data-type")) {
      let i = e.querySelector("video");
      i && i.play();
    }
    (this.autoplayStartTime = Date.now()),
      (this.autoplayTimeout = setTimeout(() => {
        this.storyNextBtnClick();
      }, this.remainingTime));
  }
  toggleIsMuted(t) {
    t.currentTarget, (this.isMuted = !this.isMuted);
    let e = this.querySelectorAll("video");
    e.forEach((t) => {
      t.muted = this.isMuted;
    }),
      this.volumeBtns.forEach((t) => {
        this.isMuted
          ? t.setAttribute("data-muted", "true")
          : t.setAttribute("data-muted", "false");
      });
  }
  touchStartHandler(t) {
    this.touchStartX = t.touches[0].clientX;
  }
  touchEndHandler(t) {
    let e = t.changedTouches[0].clientX,
      i = e - this.touchStartX;
    !(50 > Math.abs(i)) &&
      (i < 0
        ? this.activeIndex < this.lastIndex &&
          this.changeActiveStory(this.activeIndex + 1)
        : this.activeIndex > 0 && this.changeActiveStory(this.activeIndex - 1));
  }
}
customElements.define("instagram-stories", InstaStories);
